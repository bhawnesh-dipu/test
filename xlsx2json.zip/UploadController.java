package com.icici.athena.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.JsonArray;
@Controller
public class UploadController extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	private static final String UPLOADED_FOLDER = "uploads/";
	public JsonArray fArr=new JsonArray();
	@PostMapping("/upload")
    public void doPost (
            @RequestParam("file") MultipartFile uploadfile,HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {

        System.out.println("Single file upload!");
        
        if (uploadfile.isEmpty()) {
        	request.getSession().setAttribute("jsondata", "Empty");
        	request.getRequestDispatcher("/fileUpload").forward(request, response);
        }

        try {

            saveUploadedFiles((List<MultipartFile>) Arrays.asList(uploadfile));
            JsonController jobj=new JsonController(new File("uploads/MyFile.xlsx"));
            fArr=jobj.jsonConverter();
            HashMap<String,JsonArray> mp=new HashMap<String,JsonArray>();
        	request.getSession().setAttribute("jsondata",fArr.toString() );
        	request.getRequestDispatcher("/fileUpload").forward(request, response);
        
        } catch (IOException e) {
        	request.getSession().setAttribute("jsondata",fArr.toString());
        	request.getRequestDispatcher("/fileUpload").forward(request, response);
        }

    }
	 private void saveUploadedFiles(List<MultipartFile> files) throws IOException {

	        for (MultipartFile file : files) {

	            if (file.isEmpty()) {
	                continue; //next pls
	            }

	            byte[] bytes = file.getBytes();
	            Path path = Paths.get(UPLOADED_FOLDER +"MyFile.xlsx" );
	            Files.write(path, bytes);

	        }

	    }
}
