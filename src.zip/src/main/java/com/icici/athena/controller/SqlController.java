package com.icici.athena.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqlController {
	private String driverName = "oracle.jdbc.driver.OracleDriver";
	private String dbURL = "jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
	private String dbUser = "CXPSADM";
	private String dbPassword = "CXPSADM_123";
	
	
	private ResultSet result;
	public  ResultSet RunSql(String query){
	try {

		Class.forName(driverName);

	} catch (ClassNotFoundException e) {

		System.out.println("Where is your Oracle JDBC Driver?");
		//e.printStackTrace();
		return result;

	}

	System.out.println("Oracle JDBC Driver Registered!");

	Connection connection = null;

	try {

		connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

	} catch (SQLException e) {

		System.out.println("Connection Failed! Check output console");
		//e.printStackTrace();
		return result;

	}

	if (connection != null) {
		System.out.println("You made it, take control of your database now!!!!");
		try {
			Statement stmt = null;
			System.out.println(query);
			stmt = connection.createStatement();
			
			System.out.println(query);
			result = stmt.executeQuery(query);
			

			System.out.println(query);
			
			System.out.println("this is result" + result);
			
			return result;
		} catch (Exception e) {
			System.out.println("error in stmt creation:users"+e);
			// e.printStackTrace();
			return result;
		}
	} else {
		System.out.println("Failed to make connection!");
		return result;
	}
}




}
