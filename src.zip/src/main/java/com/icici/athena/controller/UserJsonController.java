package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.gson.JsonObject;

public class UserJsonController {
	private String driverName="oracle.jdbc.driver.OracleDriver";
	private String dbURL="jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
	private String dbUser="CXPSADM";
	private String dbPassword="CXPSADM_123";
	@RequestMapping(value = "/getJsonUser", method = RequestMethod.POST)
	public  String getJsonUser(@RequestParam("userid") String myuserid) throws IOException {
		JsonObject result=new JsonObject();
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("~Where is your Oracle JDBC Driver?");
			//e.printStackTrace();
			return result.toString();

		}

		System.out.println("~Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("~Connection Failed! Check output console");
			//e.printStackTrace();
			return result.toString();

		}

		if (connection != null) {
			System.out.println("~You made it, take control of your database now!");

			try {
				Statement stmt = null;
				System.out.println(myuserid.toUpperCase());
				stmt = connection.createStatement();
				System.out.println(myuserid.toUpperCase());
				String query = "SELECT * FROM TEMP_USER_TABLE WHERE user_id='"+myuserid.toUpperCase()+"'";//WHERE user_id='" + user_id + "' ;"

				
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				while(rs.next()){
				ResultSetMetaData rsmd = rs.getMetaData();
				result.addProperty("user_id",rs.getString("user_id"));
				result.addProperty("user_name",rs.getString("user_name"));
				result.addProperty("login_time",(String) rs.getObject("login_time").toString());
				result.addProperty("is_locked",rs.getString("is_locked"));
				result.addProperty("lock_time", rs.getObject("lock_time").toString());
				result.addProperty("is_superuser",rs.getString("is_superuser"));
				result.addProperty("role_id",rs.getString("role_id"));
				result.addProperty("manager_id",rs.getString("manager_id"));
				
				}
				System.out.println("~this is result" + result);
				
				return result.toString();
			} catch (SQLException  e) {
				System.out.println("~error in stmt creation"+e.getMessage());
				// e.printStackTrace();
				return result.toString();
			}
		} else {
			System.out.println("~Failed to make connection!");
			return result.toString();
		}

	}
	
	@RequestMapping(value = "/getJsonRole", method = RequestMethod.POST)
	public  String getJsonRole(@RequestParam("roleid") String myroleid) throws IOException {
		JsonObject result=new JsonObject();
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("~Where is your Oracle JDBC Driver?");
			//e.printStackTrace();
			return result.toString();

		}

		System.out.println("~Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("~Connection Failed! Check output console");
			//e.printStackTrace();
			return result.toString();

		}

		if (connection != null) {
			System.out.println("~You made it, take control of your database now!");

			try {
				Statement stmt = null;
				System.out.println(myroleid.toUpperCase());
				stmt = connection.createStatement();
				System.out.println(myroleid.toUpperCase());
				String query = "SELECT * FROM TEMP_USER_ROLE_TABLE WHERE role_id='"+myroleid.toUpperCase()+"'";//WHERE user_id='" + user_id + "' ;"

				
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				while(rs.next()){
				ResultSetMetaData rsmd = rs.getMetaData();
				result.addProperty("role_id",rs.getString("role_id"));
				result.addProperty("role_name",rs.getString("role_name"));
				result.addProperty("details",(String) rs.getObject("priviledges").toString());
				
				}
				System.out.println("~this is result" + result);
				
				return result.toString();
			} catch (SQLException  e) {
				System.out.println("~error in stmt creation"+e.getMessage());
				// e.printStackTrace();
				return result.toString();
			}
		} else {
			System.out.println("~Failed to make connection!");
			return result.toString();
		}

	}
	

	@RequestMapping(value = "/getJsonGrant", method = RequestMethod.POST)
	public  String getJsonGrant(@RequestParam("grantid") String mygrantid) throws IOException {
		JsonObject result=new JsonObject();

		
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return result.toString();

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return result.toString();

		}

		if (connection != null) {
			System.out.println("You made it, take control of your database now!");

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "SELECT * FROM TEMP_USER_GRANT_TABLE WHERE grant_id='" + mygrantid + "' ";


				
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				ResultSetMetaData rsmd = rs.getMetaData();

				int columnsNumber = rsmd.getColumnCount();
				/*
				 * for(int i = 1; i <= columnsNumber; i++) {
				 * result+="<th>"+(rsmd.getColumnName(i))+"</th>"; }
				 * result+="</tr>";
				 * 
				 */
				
				while (rs.next()) {
					
					result.addProperty("grant_id",rs.getString("grant_id"));
					result.addProperty("granter_name",rs.getString("granter_name"));
					result.addProperty("granter_id",(String) rs.getObject("granter_id").toString());
					result.addProperty("role_id", rs.getString("role_id"));
					result.addProperty("grantee_id",rs.getString("grantee_id"));
					result.addProperty("grantee_name", rs.getObject("grantee_name").toString());
					result.addProperty("can_grant",rs.getString("can_grant"));
					result.addProperty("app_id",rs.getString("app_id"));
					result.addProperty("is_valid_grant",rs.getString("is_valid_grant"));
					
				}
				
				System.out.println("this is result" + result);
				if (result.size() == 0) {
					System.out.println("There is no data for this question.");
					return result.toString();
				}
				return result.toString();
			} catch (Exception e) {
				System.out.println("error in stmt creation");
				// e.printStackTrace();
				return result.toString();
			}
		} else {
			System.out.println("Failed to make connection!");
			return result.toString();
		}

	}
	

	@RequestMapping(value = "/getJsonApp", method = RequestMethod.POST)
	public  String getJsonApp(@RequestParam("appid") String myappid) throws IOException {
		JsonObject result=new JsonObject();

		
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return result.toString();

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return result.toString();

		}

		if (connection != null) {
			System.out.println("You made it, take control of your database now!");

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "SELECT * FROM TEMP_USER_APP_TABLE WHERE app_id='" + myappid + "' ";


				
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				ResultSetMetaData rsmd = rs.getMetaData();

				int columnsNumber = rsmd.getColumnCount();
				/*
				 * for(int i = 1; i <= columnsNumber; i++) {
				 * result+="<th>"+(rsmd.getColumnName(i))+"</th>"; }
				 * result+="</tr>";
				 * 
				 */
				
				while (rs.next()) {
					
					result.addProperty("app_id",rs.getString("app_id"));
					result.addProperty("app_name",rs.getString("app_name"));
					result.addProperty("user_id",(String) rs.getObject("user_id").toString());
					
					result.addProperty("created_date", rs.getObject("created_date").toString());
					result.addProperty("user_name",rs.getString("user_name"));
					
					
				}
				
				System.out.println("this is result" + result);
				if (result.size() == 0) {
					System.out.println("There is no data for this question.");
					return result.toString();
				}
				return result.toString();
			} catch (Exception e) {
				System.out.println("error in stmt creation");
				// e.printStackTrace();
				return result.toString();
			}
		} else {
			System.out.println("Failed to make connection!");
			return result.toString();
		}

	}
	
	
}
