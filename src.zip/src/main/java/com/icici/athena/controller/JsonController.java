package com.icici.athena.controller;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import static java.lang.Integer.parseInt;

public class JsonController {
	public static DataFormatter formatter = new DataFormatter();
	public File file = null;

	public JsonController() {
		file = new File("uploads/Test.xlsx");
	}

	public JsonController(File myfile) {
		this.file = myfile;

	}
	

    public static String  getQuestionBlock(XSSFSheet ws,int row) {
        System.out.println("getQuestionBlock:"+row+"last row:"+ws.getPhysicalNumberOfRows());
        int rown=row;
        for (int i = row+1 ; i < ws.getPhysicalNumberOfRows()-1 && ws.getRow(i)!=null;i++) {
            XSSFCell cell;
            cell = ws.getRow(i).getCell(0);

            System.out.println(formatter.formatCellValue(cell).toString().trim()+":::"+i);
            if(formatter.formatCellValue(cell).toString().trim().equals("")){

            }else{
                return new String(row+"#"+(rown));
            }
            rown=i;

        }
        return new String(row+"#"+(rown));

    }

    public static String  getQuestionBlock(XSSFSheet ws,int row,int col) {
    	if(col>256) {
    		return row+"#"+(row);
    	}
    	System.out.println("getQuestionBlock:"+row+" col"+col);
        int rown=row;
        for (int i = row+1 ; i < ws.getPhysicalNumberOfRows()-1 && ws.getRow(i)!=null;i++) {

            XSSFCell cell;
             cell=ws.getRow(i).getCell(col);
            
            //System.out.println(formatter.formatCellValue(cell).toString().trim()+":::"+i);
            if(formatter.formatCellValue(cell).toString().trim().equals("")){

            }else{
                return new String(row+"#"+(rown));
            }
            rown=i;
        }
        return new String(row+"#"+(rown));
    }

    public static int countInnerQ(XSSFSheet st,int rows,int rowe,int col) {
    	if(col>256) {
    		return 0;
    	}
    	int k = 0;
        boolean que=false;
        for (int i = rows; i <= rowe && st.getRow(i)!=null; i++) {
            XSSFCell cell = st.getRow(i).getCell(col );
            if(col+1<=st.getRow(i).getLastCellNum()){
                XSSFCell cellnext = st.getRow(i).getCell(col+1 );
                if(!formatter.formatCellValue(cell).toString().trim().equals("")){
                        que=true;
                }
            }
            //System.out.println("Cell Data:"+formatter.formatCellValue(cell).toString().trim()+"::row::"+i+":col:"+col);


            if (formatter.formatCellValue(cell).toString().trim().equals("")) {

            }else {
                k++;
            }
        }
        System.out.println("countInnerQ():rows:"+rows+" rowe:"+rowe+" Col:"+col);

        System.out.println("countInnerQ()=:"+k);
        if(que)
            return k;
        else
            return 0;

    }

    public static int countInnerA(XSSFSheet st,int rows,int rowe,int col) {
    	if(col>256) {
    		return 0;
    	}
    	int k = 0;
        for (int i = col;st.getRow(rows)!=null && i <= st.getRow(rows).getLastCellNum(); i++) {
            XSSFCell cell;
            	cell = st.getRow(rows).getCell(i);
           
            //System.out.println("Cell Data:"+formatter.formatCellValue(cell).toString().trim()+"::row::"+i+":col:"+col);
            if (formatter.formatCellValue(cell).toString().trim().equals("")) {

            } else {
                k++;
            }
        }
        System.out.println("countInnerA():rows:"+rows+" rowe:"+rowe+" Col:"+col);

        System.out.println("countInnerA()=:"+k);

        return k;

    }



    public JsonArray jsonConverter() throws IOException {
        JsonArray fArr = new JsonArray();

        FileInputStream fIP = new FileInputStream(file);
        System.out.println(file.getName()+" "+file.getCanonicalPath());
        XSSFWorkbook workbook = new XSSFWorkbook(fIP);
        if (file.isFile() && file.exists()) {
            System.out.println("file.xlsx file open successfully.");
                    XSSFSheet spreadsheet =workbook.getSheetAt(0);
            int k=0;
            for (int i = 1; i < spreadsheet.getPhysicalNumberOfRows();i++) {
                String temp=getQuestionBlock(spreadsheet,i);
                System.out.println(temp);
                k=parseInt(temp.substring(temp.lastIndexOf('#')+1));
                JsonObject  fobj=toJson(spreadsheet,i,k,0);
                if(fobj.entrySet().size()>0) {
                	fArr.add(fobj);
                }
                System.out.println("Final JSON::"+fobj.toString());
                i=k;
                
            }
            } else {
            System.out.println("Error to open file.xlsx file.");
        }
        workbook.close();
        return fArr;
    }


    public static JsonArray toJsonArray(XSSFSheet st,int rows,int rowe,int col){
    	if(col>256) {
    		return new JsonArray();
    	}
        System.out.println("To JSON ARRAY"+"rows:"+rows+" rowe:"+rowe+" col:"+col);
        JsonArray jArr=new JsonArray();
        int k=0;
        for(int i=rows;i<=rowe;i++){
                JsonObject tobj=new JsonObject();
                String temp=getQuestionBlock(st,i,col);
                System.out.println("JSONArray:Temp:"+temp);
                k=parseInt(temp.substring(temp.lastIndexOf('#')+1));
                System.out.println("Going to JSONObject From Array in Loop: rows"+i+" krowe:"+k);
                tobj=toJson(st,i,k,col);
                
                System.out.println("tobj.ToString():"+tobj.toString());

                i=k;
                if(tobj.entrySet().size()>0)
                jArr.add(tobj);
            }
        return jArr;
    }

    public static JsonObject toJson(XSSFSheet st,int rows,int rowe,int col){
    	if(st.getRow(rows)==null){
    		return new JsonObject();
    	}
    	if(col>256) {
    		return new JsonObject();
    	}
    	System.out.println("To JSON OBJECT"+"rows:"+rows+" rowe:"+rowe+" col:"+col);

        JsonObject obj=new JsonObject();
        XSSFCell cell=null;
        if(st.getRow(rows)!=null)
        	cell= st.getRow(rows).getCell(col);
        int countQ=countInnerQ(st,rows,rowe,col+1);
        int countA=countInnerA(st,rows,rowe,col+1);
        int countS=countInnerQ(st,rows,rowe,col+2);

        if(countQ>1){
            JsonArray objArr;
            System.out.println("countQ>1:"+formatter.formatCellValue(cell).toString().trim());

            objArr=toJsonArray(st,rows,rowe,col+1);
            obj.addProperty("question",formatter.formatCellValue(cell).toString().trim());
            for(int i=0;i<objArr.size();i++) {
            	if((objArr.get(i).getAsJsonObject()).entrySet().size()==0) {
            		objArr.remove(i);
            	}
            }
            obj.add("conv_ans",objArr);
        }else if(countQ==1 && countA==1 ){

            System.out.println("countQ="+countQ+"countA=="+countA+" && col==0 :"+formatter.formatCellValue(cell).toString().trim());
            obj.addProperty("question",formatter.formatCellValue(cell).toString().trim());
            obj.addProperty("answer",formatter.formatCellValue(st.getRow(rows).getCell(col+1)).toString().trim());

        }else if(countS>1){

            obj.addProperty("solution",formatter.formatCellValue(st.getRow(rows).getCell(col+1)).toString().trim());

            JsonArray tarr=toJsonArray(st,rows,rowe,col+2);
            for(int i=0;i<tarr.size();i++) {
            	if((tarr.get(i).getAsJsonObject()).entrySet().size()==0) {
            		tarr.remove(i);
            	}
            }
            obj.add("conv_ans",tarr);
        }else {
        	obj.addProperty("question",formatter.formatCellValue(st.getRow(rows).getCell(col+1)).toString().trim());

            JsonArray tarr=toJsonArray(st,rows,rowe,col+1);
            for(int i=0;i<tarr.size();i++) {
            	if((tarr.get(i).getAsJsonObject()).entrySet().size()==0) {
            		tarr.remove(i);
            	}
            }
            obj.add("conv_ans",tarr);

        }
        return obj;
    }
}