package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import oracle.sql.TIMESTAMP;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.icici.athena.app.App;
import com.icici.athena.grant.Grant;
import com.icici.athena.role.Role;
import com.icici.athena.user.User;


@Configuration
@Component
@RestController
public class UserController {
	private String driverName="oracle.jdbc.driver.OracleDriver";
	private String dbURL="jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
	private String dbUser="CXPSADM";
	private String dbPassword="CXPSADM_123";
	// user query execution method
	@RequestMapping(value = "/getUsers", method = RequestMethod.POST)
	public ArrayList<User> getUsers(User user)throws IOException {

		System.out.println(driverName);

		System.out.println(dbURL);

		System.out.println(dbUser);

		System.out.println(dbPassword);
		

		ArrayList<User> result = new ArrayList<User>();
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			//e.printStackTrace();
			return result;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			//e.printStackTrace();
			return result;

		}

		if (connection != null) {
			System.out.println("USER ID"+user.getUser_id());
			System.out.println("You made it, take control of your database now!!!!");
			String query="";
			try {
				Statement stmt = null;
				System.out.println(user.getUser_id());
				query = "SELECT * FROM TEMP_USER_TABLE WHERE manager_id='" + user.getUser_id() + "' ;";
				 System.out.println(query);
				stmt = connection.createStatement();
				
				query = "SELECT * FROM TEMP_USER_TABLE WHERE manager_id='" + user.getUser_id() + "' ;";
				 System.out.println(query);
				if (user.getIs_superuser() == "YES") {
					query = "SELECT * FROM TEMP_USER_TABLE  ";

				} else {
					query = "SELECT * FROM TEMP_USER_TABLE WHERE manager_id='" + user.getUser_id().toUpperCase() + "' ";

				}
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				ResultSetMetaData rsmd = rs.getMetaData();

				int columnsNumber = rsmd.getColumnCount();
				/*
				 * for(int i = 1; i <= columnsNumber; i++) {
				 * result+="<th>"+(rsmd.getColumnName(i))+"</th>"; }
				 * result+="</tr>";
				 * 
				 */
				System.out.println(query);
				while (rs.next()) {
					User temp = new User();
					temp.setUser_id(rs.getString("user_id"));
					temp.setUser_name(rs.getString("user_name"));
					temp.setLogin_time((TIMESTAMP) rs.getObject("login_time"));
					temp.setIs_locked(rs.getString("is_locked"));
					temp.setLock_time((TIMESTAMP) rs.getObject("lock_time"));
					temp.setIs_superuser(rs.getString("is_superuser"));
					temp.setRole_id(rs.getString("role_id"));
					temp.setManager_id(rs.getString("manager_id"));
					result.add(temp);
				}
				System.out.println("this is result" + result);
				if (result.size() == 0) {
					System.out.println("There is no data for this question.");
					return result;
				}
				return result;
			} catch (Exception e) {
				System.out.println("error in stmt creation:users"+e);
				// e.printStackTrace();
				return result;
			}
		} else {
			System.out.println("Failed to make connection!");
			return result;
		}

	}

	@RequestMapping(value = "/getRoles", method = RequestMethod.POST)
	public  ArrayList<Role> getRoles(User user) throws IOException {

		ArrayList<Role> result = new ArrayList<Role>();
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return result;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return result;

		}

		if (connection != null) {
			System.out.println("You made it, take control of your database now!");

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "";

				if (user.getIs_superuser().equals("YES")) {
					query = "SELECT * FROM TEMP_USER_ROLE_TABLE  ";

				}
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				ResultSetMetaData rsmd = rs.getMetaData();

				int columnsNumber = rsmd.getColumnCount();
				/*
				 * for(int i = 1; i <= columnsNumber; i++) {
				 * result+="<th>"+(rsmd.getColumnName(i))+"</th>"; }
				 * result+="</tr>";
				 * 
				 */
				
				while (rs.next()) {
					Role temp = new Role();
					temp.setRole_id(rs.getString("role_id"));
					temp.setRole_name(rs.getString("role_name"));
					temp.setPriviledges(rs.getString("priviledges"));
					result.add(temp);
				}
				System.out.println("this is result" + result);
				if (result.size() == 0) {
					System.out.println("There is no data for this question.");
					return result;
				}
				return result;
			} catch (Exception e) {
				System.out.println("error in stmt creation");
				// e.printStackTrace();
				return result;
			}
		} else {
			System.out.println("Failed to make connection!");
			return result;
		}

	}

	@RequestMapping(value = "/getApps", method = RequestMethod.POST)
	public  ArrayList<App> getApps(User user) throws IOException {

		ArrayList<App> result = new ArrayList<App>();
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return result;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return result;

		}

		if (connection != null) {
			System.out.println("You made it, take control of your database now!");

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "SELECT * FROM TEMP_USER_APP_TABLE WHERE user_id='" + user.getUser_id() + "' ";

				if (user.getIs_superuser().equals("YES")) {
					query = "SELECT * FROM TEMP_USER_APP_TABLE ";

				} else {
					query = "SELECT * FROM TEMP_USER_APP_TABLE WHERE user_id='" + user.getUser_id() + "' ";

				}
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				ResultSetMetaData rsmd = rs.getMetaData();

				int columnsNumber = rsmd.getColumnCount();
				/*
				 * for(int i = 1; i <= columnsNumber; i++) {
				 * result+="<th>"+(rsmd.getColumnName(i))+"</th>"; }
				 * result+="</tr>";
				 * 
				 */
				
				while (rs.next()) {
					App temp = new App();
					temp.setUser_id(rs.getString("user_id"));
					temp.setUser_name(rs.getString("user_name"));
					temp.setApp_id(rs.getString("app_id"));
					temp.setApp_name(rs.getString("app_name"));
					temp.setCreated_date((TIMESTAMP) rs.getObject("created_date"));
					result.add(temp);
				}
				System.out.println("this is result" + result);
				if (result.size() == 0) {
					System.out.println("There is no data for this question.");
					return result;
				}
				return result;
			} catch (Exception e) {
				System.out.println("error in stmt creation");
				// e.printStackTrace();
				return result;
			}
		} else {
			System.out.println("Failed to make connection!");
			return result;
		}
	}

	@RequestMapping(value = "/getGrants", method = RequestMethod.POST)
	public  ArrayList<Grant> getGrants(User user) throws IOException {

		ArrayList<Grant> result = new ArrayList<Grant>();
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return result;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return result;

		}

		if (connection != null) {
			System.out.println("You made it, take control of your database now!");

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "SELECT * FROM TEMP_USER_GRANT_TABLE WHERE granter_id='" + user.getUser_id() + "' ";

				if (user.getIs_superuser().equals("YES")) {
					query = "SELECT * FROM TEMP_USER_GRANT_TABLE  ";

				} else {
					query = "SELECT * FROM TEMP_USER_GRANT_TABLE WHERE granter_id='" + user.getUser_id() + "' ";

				}
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				ResultSetMetaData rsmd = rs.getMetaData();

				int columnsNumber = rsmd.getColumnCount();
				/*
				 * for(int i = 1; i <= columnsNumber; i++) {
				 * result+="<th>"+(rsmd.getColumnName(i))+"</th>"; }
				 * result+="</tr>";
				 * 
				 */
				
				while (rs.next()) {
					Grant temp = new Grant();
					temp.setGrant_id(rs.getString("grant_id"));
					temp.setGranter_name(rs.getString("granter_name"));
					temp.setGranter_id( rs.getString("granter_id"));
					temp.setRole_id(rs.getString("role_id"));
					temp.setGrantee_id(rs.getString("grantee_id"));
					temp.setGrantee_name( rs.getString("grantee_name"));
					temp.setCan_grant(rs.getString("can_grant"));
					temp.setApp_id(rs.getString("app_id"));
					temp.setIs_valid_grant(rs.getString("is_valid_grant"));
					result.add(temp);
				}
				
				System.out.println("this is result" + result);
				if (result.size() == 0) {
					System.out.println("There is no data for this question.");
					return result;
				}
				return result;
			} catch (Exception e) {
				System.out.println("error in stmt creation");
				// e.printStackTrace();
				return result;
			}
		} else {
			System.out.println("Failed to make connection!");
			return result;
		}

	}
	
	
	
	@RequestMapping(value = "/getUser", method = RequestMethod.POST)
	public  User getUser(String myuserid) throws IOException {
		User result=new User();
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("~Where is your Oracle JDBC Driver?");
			//e.printStackTrace();
			return result;

		}

		System.out.println("~Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("~Connection Failed! Check output console");
			//e.printStackTrace();
			return result;

		}

		if (connection != null) {
			System.out.println("~You made it, take control of your database now!");

			try {
				Statement stmt = null;
				System.out.println(myuserid.toUpperCase());
				stmt = connection.createStatement();
				System.out.println(myuserid.toUpperCase());
				String query = "SELECT * FROM TEMP_USER_TABLE WHERE user_id='"+myuserid.toUpperCase()+"'";//WHERE user_id='" + user_id + "' ;"

				
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				while(rs.next()){
				ResultSetMetaData rsmd = rs.getMetaData();
				result.setUser_id(rs.getString("user_id"));
				result.setUser_name(rs.getString("user_name"));
				result.setLogin_time((TIMESTAMP) rs.getObject("login_time"));
				result.setIs_locked(rs.getString("is_locked"));
				result.setLock_time((TIMESTAMP) rs.getObject("lock_time"));
				result.setIs_superuser(rs.getString("is_superuser"));
				result.setRole_id(rs.getString("role_id"));
				result.setManager_id(rs.getString("manager_id"));
				
				}
				System.out.println("~this is result" + result);
				
				return result;
			} catch (SQLException  e) {
				System.out.println("~error in stmt creation"+e.getMessage());
				// e.printStackTrace();
				return result;
			}
		} else {
			System.out.println("~Failed to make connection!");
			return result;
		}

	}
	
	
	@RequestMapping(value = "/insertUser", method = RequestMethod.POST)
	public int insertUser(
			@RequestParam(value="myuser_id",required=false) String myuserid, 			
			@RequestParam(value="myuser_name",required=false) String myusername,
			@RequestParam(value="myrole_id",required=false) String myroleid,
			@RequestParam(value="mymanager_id",required=false) String mymanagerid,
			@RequestParam(value="myis_superuser",required=false) String myissuperuser,
			@RequestParam(value="myis_locked",required=false) String myislocked,
			
			
			
			HttpServletRequest request ) throws IOException {
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return -1;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			System.out.println("You made it, take control of your database now!");

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "INSERT INTO TEMP_USER_TABLE (user_id, user_name,manager_id,login_time,is_locked,lock_time,is_superuser,role_id ) "
						+ "VALUES "
						+ "('"+myuserid+"','"+myusername+"','"+mymanagerid+"',SYSDATE,'"+myislocked+"',SYSDATE,'"+myissuperuser+"','"+myroleid+"')";



				
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				
				
			
				
				
				return 1;
			} catch (Exception e) {
				System.out.println("error in insert stmt creation");
				// e.printStackTrace();
				return -1;
			}
		} else {
			System.out.println("Failed to make connection!");
			return -1;
		}
		
		
		
	}
	

	@RequestMapping(value = "/commit", method = RequestMethod.POST)
	public int commit(HttpServletRequest request ) throws IOException {
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return -1;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			System.out.println("You made it, take control of your database now!");

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "COMMIT";


				
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				
			
				
				
				return 1;
			} catch (Exception e) {
				System.out.println("error in commit creation");
				// e.printStackTrace();
				return -1;
			}
		} else {
			System.out.println("Failed to make connection!");
			return -1;
		}
		
		
		
	}
	
	@RequestMapping(value = "/insertRole", method = RequestMethod.POST)
	public int insertRole(			
			@RequestParam(value="myrole_name",required=false) String myrolename,
			@RequestParam(value="myrole_details",required=false) String myroledetails,
						
			HttpServletRequest request ) throws IOException {
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return -1;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			System.out.println("You made it, take control of your database now!");

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "INSERT INTO TEMP_USER_ROLE_TABLE (role_id, role_name,priviledges ) VALUES "
						+ "('','"+myrolename+"','"+myroledetails+"')";



				
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				
				
			
				
				
				return 1;
			} catch (Exception e) {
				System.out.println("error in insert stmt creation");
				// e.printStackTrace();
				return -1;
			}
		} else {
			System.out.println("Failed to make connection!");
			return -1;
		}
		
		
		
	}	
	
	@RequestMapping(value = "/insertGrant", method = RequestMethod.POST)
	public int insertGrant(			
			@RequestParam(value="mygranter_id",required=false) String mygranterid,
			@RequestParam(value="mygranter_name",required=false) String mygrantername,
			@RequestParam(value="myrole_id",required=false) String myroleid,
			@RequestParam(value="myapp_id",required=false) String myappid,
			@RequestParam(value="mygrantee_id",required=false) String mygranteeid,
			@RequestParam(value="mygrantee_name",required=false) String mygranteename,
			@RequestParam(value="can_grant",required=false) String cangrant,
			@RequestParam(value="is_validGrant",required=false) String isvalidgrant,
			
			HttpServletRequest request ) throws IOException {
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return -1;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			System.out.println("You made it, take control of your database now!");

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "INSERT INTO TEMP_USER_GRANT_TABLE (grant_id,granter_id,granter_name,role_id,app_id,grantee_id,grantee_name,can_grant,is_valid_grant ) VALUES "
						+ "('','"+mygranterid+"','"+mygrantername+"','"+myroleid+"','"+myappid+"','"+mygranteeid+"','"+mygranteename+"','"+cangrant+"','"+isvalidgrant+"')";



				
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				
				
			
				
				
				return 1;
			} catch (Exception e) {
				System.out.println("error in insert stmt creation");
				// e.printStackTrace();
				return -1;
			}
		} else {
			System.out.println("Failed to make connection!");
			return -1;
		}
		
		
		
	}
	
	
	
}
