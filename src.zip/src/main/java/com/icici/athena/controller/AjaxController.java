package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import javax.naming.ldap.LdapContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
/* end import added by dipu */
import com.icici.athena.ldap.LDAPUtil;
import com.icici.athena.user.User;

@Configuration
@Component 
@RestController
public class AjaxController {
	
	public  static Logger athena = LoggerFactory.getLogger("athena-log");
	public  static Logger audit = LoggerFactory.getLogger("athena-audit-log");
	public  static Logger athenaUser = LoggerFactory.getLogger("athena-User-log");
	public  static Logger athenaActivity = LoggerFactory.getLogger("athena-Activity-log");
	public  static Logger athenaUserActivity = LoggerFactory.getLogger("athena-User-Activity-log");

	
	public String appname = null;
	
	///////////////////////User Activity Log Controller///////////////////////////////////////
	@RequestMapping(value = "/Activitylog", method = RequestMethod.POST)
	public static void Activitylog(
			@RequestParam(value="appName",required=false) String appName, 			
			@RequestParam(value="question",required=false) String question,
			@RequestParam(value="Action",required=false) String action,
			@RequestParam(value="QueID",required=false) String id,
			
			HttpServletRequest request ) throws IOException {
		 		
		
				
				if(question.length()==0){
					question="NULL";
				}
				if(action.length()==0){
					action="NOTHING";
				}
				
				action="ACTION_{ "+action+" }";
				question = "QUESTION_{ "+question+" }";
								
				athenaActivity.info(" , "+request.getRemoteAddr()+" , "+request.getSession().getId()+" , APPNAME_"+appName+" , "+action+" , "+question+" , "+id);
				
	
	}
	@RequestMapping(value = "/UserActivitylog", method = RequestMethod.POST)
	public static void loginLog(
			@RequestParam(value="id",required=false) String id, 			
			@RequestParam(value="action",required=false) String action,@RequestParam(value="sid",required=false) String sid,
			
			HttpServletRequest request ) throws IOException {
		 		
		
				
				if(action.length()==0){
					action="NOTHING";
				}
				
				action="ACTION_{ "+action+" }";
				
				if(sid.equals("NULL")){
					athenaUserActivity.info(" , "+request.getRemoteAddr()+" , "+request.getSession().getId()+" , "+action+" , "+id);
					
				}else{
					athenaUserActivity.info(" , "+request.getRemoteAddr()+" , "+sid+" , "+action+" , "+id);
				}
	
	}
	//////////////////////////////////////////////////////////////////////////////////////////
	
	@RequestMapping(value = "/log", method = RequestMethod.POST)
	public static void log(
			@RequestParam(value="appName",required=false) String appName, 
			@RequestParam(value="q",required=false) String query,
			@RequestParam(value="thumbs",required=false) String thumbs,
			@RequestParam(value="question",required=false) String question,
			@RequestParam(value="wanted",required=false) String wanted,
			@RequestParam(value="message",required=false) String msg,
			
			HttpServletRequest request ) throws IOException {
		 		
		
				if (query.length()==0){
					query="NO_USER_QUERY";
				}
				if(thumbs.equals("UP")){
					wanted="YES";
				}
				else if(thumbs.equals("DOWN")){
					wanted="NO";
				}
				if(wanted.length()==0){
					wanted="NULL";
				}
				if(question.length()==0){
					question="NULL";
				}
				if(msg.length()==0){
					msg="NULL";
				}
				query="USER_QUERY_{ "+query+" }";
				wanted = "WANTED_"+wanted;
				thumbs="THUMBS_"+thumbs;
				msg="MESSAGE_{ "+msg+" }";
				question = "QUESTION_{ "+question+" }";
								
				athena.info(" , "+request.getRemoteAddr()+" , "+request.getSession().getId()+" , APPNAME_"+appName+" , "+query+" , "+thumbs+" , "+msg+" , "+wanted+" , "+question);
				
	
	}
	@RequestMapping(value = "/Userlog", method = RequestMethod.POST)
	public static void Userlog(
			@RequestParam(value="appName",required=false) String appName, 
			@RequestParam(value="q",required=false) String query,
			@RequestParam(value="thumbs",required=false) String thumbs,
			@RequestParam(value="question",required=false) String question,
			@RequestParam(value="wanted",required=false) String wanted,
			@RequestParam(value="message",required=false) String msg,
			
			HttpServletRequest request ) throws IOException {
		 		
		
				if (query.length()==0){
					query="NO_USER_QUERY";
				}
				if(thumbs.equals("UP")){
					wanted="YES";
				}
				else if(thumbs.equals("DOWN")){
					wanted="NO";
				}
				if(wanted.length()==0){
					wanted="NULL";
				}
				if(question.length()==0){
					question="NULL";
				}
				if(msg.length()==0){
					msg="NULL";
				}
				query="USER_QUERY_{ "+query+" }";
				wanted = "WANTED_"+wanted;
				thumbs="THUMBS_"+thumbs;
				msg="MESSAGE_{ "+msg+" }";
				question = "QUESTION_{ "+question+" }";
								
				athenaUser.info(" , "+request.getRemoteAddr()+" , "+request.getSession().getId()+" , APPNAME_"+appName+" , "+query+" , "+thumbs+" , "+msg+" , "+wanted+" , "+question);
				
	
	}
	
	
	
	@RequestMapping(value = "/getvalue", method = RequestMethod.GET)
	public String getResource(@RequestParam("appName") String appName, @RequestParam("q") String query,HttpServletRequest request ) throws IOException {
		
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		//String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";
		String body = "{\"size\": 1,\"query\":{\"function_score\":{\"query\":{\"match\":{\"question\":{\"query\":\""+query+"\",\"operator\":\"or\"}}},\"boost\":\"1\",\"random_score\":{},\"boost_mode\":\"multiply\"}}}";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response = restClient.performRequest("POST", "/chatbot_new/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		System.out.println("\n Query: "+query+"\n Result: "+result);
		System.out.println("LOGGER,"+request.getRemoteAddr()+","+request.getRemoteHost()+","+request.getRemoteUser()+","+query);
		
		restClient.close();
		return result;
	}
	
	@RequestMapping(value = "/searchQuery", method = RequestMethod.GET)
	public String getResources(@RequestParam("appName") String appName, @RequestParam("q") String query) throws IOException {
		//String str= 
		StringBuffer sbquery=new StringBuffer(query);
		// added to remove stopwords
		String[] stopwords={"a","able","about","above","abst","accordance","according","accordingly","across","act","actually","added","adj","affected","affecting","affects","after","afterwards","again","against","ah","all","almost","alone","along","already","also","although","always","am","among","amongst","an","and","announce","another","any","anybody","anyhow","anymore","anyone","anything","anyway","anyways","anywhere","apparently","approximately","are","aren","arent","arise","around","as","aside","ask","asking","at","auth","available","away","awfully","b","back","be","became","because","become","becomes","becoming","been","before","beforehand","begin","beginning","beginnings","begins","behind","being","believe","below","beside","besides","between","beyond","biol","both","brief","briefly","but","by","c","ca","came","can","cannot","can't","cause","causes","certain","certainly","co","com","come","comes","contain","containing","contains","could","couldnt","d","date","did","didn't","different","do","does","doesn't","doing","done","don't","down","downwards","due","during","e","each","ed","edu","effect","eg","eight","eighty","either","else","elsewhere","end","ending","enough","especially","et","et-al","etc","even","ever","every","everybody","everyone","everything","everywhere","ex","except","f","far","few","ff","fifth","first","five","fix","followed","following","follows","for","former","formerly","forth","found","four","from","further","furthermore","g","gave","get","gets","getting","give","given","gives","giving","go","goes","gone","got","gotten","h","had","happens","hardly","has","hasn't","have","haven't","having","he","hed","hence","her","here","hereafter","hereby","herein","heres","hereupon","hers","herself","hes","hi","hid","him","himself","his","hither","home","how","howbeit","however","hundred","i","id","ie","if","i'll","im","immediate","immediately","importance","important","in","inc","indeed","index","information","instead","into","invention","inward","is","isn't","it","itd","it'll","its","itself","i've","j","just","k","keep","keeps","kept","kg","km","know","known","knows","l","largely","last","lately","later","latter","latterly","least","less","lest","let","lets","like","liked","likely","line","little","'ll","look","looking","looks","ltd","m","made","mainly","make","makes","many","may","maybe","me","mean","means","meantime","meanwhile","merely","mg","might","million","miss","ml","more","moreover","most","mostly","mr","mrs","much","mug","must","my","myself","n","na","name","namely","nay","nd","near","nearly","necessarily","necessary","need","needs","neither","never","nevertheless","new","next","nine","ninety","no","nobody","non","none","nonetheless","noone","nor","normally","nos","not","noted","nothing","now","nowhere","o","obtain","obtained","obviously","of","off","often","oh","ok","okay","old","omitted","on","once","one","ones","only","onto","or","ord","other","others","otherwise","ought","our","ours","ourselves","out","outside","over","overall","owing","own","p","page","pages","part","particular","particularly","past","per","perhaps","placed","please","plus","poorly","possible","possibly","potentially","pp","predominantly","present","previously","primarily","probably","promptly","proud","provides","put","q","que","quickly","quite","qv","r","ran","rather","rd","re","readily","really","recent","recently","ref","refs","regarding","regardless","regards","related","relatively","research","respectively","resulted","resulting","results","right","run","s","said","same","saw","say","saying","says","sec","section","see","seeing","seem","seemed","seeming","seems","seen","self","selves","sent","seven","several","shall","she","shed","she'll","shes","should","shouldn't","show","showed","shown","showns","shows","significant","significantly","similar","similarly","since","six","slightly","so","some","somebody","somehow","someone","somethan","something","sometime","sometimes","somewhat","somewhere","soon","sorry","specifically","specified","specify","specifying","still","stop","strongly","sub","substantially","successfully","such","sufficiently","suggest","sup","sure","t","take","taken","taking","tell","tends","th","than","thank","thanks","thanx","that","that'll","thats","that've","the","their","theirs","them","themselves","then","thence","there","thereafter","thereby","thered","therefore","therein","there'll","thereof","therere","theres","thereto","thereupon","there've","these","they","theyd","they'll","theyre","they've","think","this","those","thou","though","thoughh","thousand","throug","through","throughout","thru","thus","til","tip","to","together","too","took","toward","towards","tried","tries","truly","try","trying","ts","twice","two","u","un","under","unfortunately","unless","unlike","unlikely","until","unto","up","upon","ups","us","use","used","useful","usefully","usefulness","uses","using","usually","v","value","various","'ve","very","via","viz","vol","vols","vs","w","want","wants","was","wasn't","way","we","wed","welcome","we'll","went","were","weren't","we've","what","whatever","what'll","whats","when","whence","whenever","where","whereafter","whereas","whereby","wherein","wheres","whereupon","wherever","whether","which","while","whim","whither","who","whod","whoever","whole","who'll","whom","whomever","whos","whose","why","widely","willing","wish","with","within","without","won't","words","world","would","wouldn't","www","x","y","yes","yet","you","youd","you'll","your","youre","yours","yourself","yourselves","you've","z","zero"};
        String[] arrq=query.split(" ");
        ArrayList<String>arlist=new ArrayList<String>(Arrays.asList(stopwords));
        for(String temp:arrq){
        	if(arlist.contains(temp)){
        		int start=sbquery.indexOf(temp);
        		
        		sbquery.replace(start,start+temp.length() , "");
        	}
        }
		
		query=new String(sbquery);
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		//String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";
		String body = "{ \"size\":5, \"query\": { \"match\": { \"_all\": { \"query\": \""+query+"\", \"operator\": \"and\" } } } }";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response = restClient.performRequest("POST", "/chatbot_new/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		System.out.println("\n Query: "+query+"\n Result: "+result);
		return result;
	}
	
	@RequestMapping(value = "/searchCompany", method = RequestMethod.GET)
	public String getCompany(@RequestParam("appName") String appName, @RequestParam("q") String query) throws IOException {
		//String str= 
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		//String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";
		String body = "{ \"size\": 1, \"query\": { \"match\": { \"UCC_CODE\": { \"query\": \""+query+"\" } } } }";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response = restClient.performRequest("POST", "/chatbot_new/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		return result;
	}
	
	/* start   added by dipu execute the given query */
	
	@RequestMapping(value = "/executeQuery", method = RequestMethod.GET)
	public String executeQuery(@RequestParam("appName") String appName, @RequestParam("q") String query,@Value("${spring.datasource.driver-class-name}") String driverName,@Value("${spring.datasource.url}") String dbURL,@Value("${spring.datasource.username}") String dbUser,@Value("${spring.datasource.password}") String dbPassword) throws IOException {
		
		String result="";
		try {
			
	        Class.forName(driverName);

	    } catch (ClassNotFoundException e) {

	        System.out.println("Where is your Oracle JDBC Driver?");
	        e.printStackTrace();
	        return "Oracle Driver not found";

	    }

	    System.out.println("Oracle JDBC Driver Registered!");

	    Connection connection = null;
        
	    try {

	      connection = DriverManager.getConnection(dbURL, dbUser, dbPassword); 

	    } catch (SQLException e) {

	        System.out.println("Connection Failed! Check output console");
	        e.printStackTrace();
	        return "connection failed ";

	    }

	    if (connection != null) {
	        System.out.println("You made it, take control of your database now!");
	        
	        try{
	        Statement stmt = null;
	        stmt=connection.createStatement();
	        System.out.println(query);
	        ResultSet rs = stmt.executeQuery(query);
	        ResultSetMetaData rsmd = rs.getMetaData();

	        
	        result+="<table  >";
	        int columnsNumber = rsmd.getColumnCount();
	        /*for(int i = 1; i <= columnsNumber; i++)
	        {
	            result+="<th>"+(rsmd.getColumnName(i))+"</th>";
	        }
	        result+="</tr>";
	        
	        */
	        while (rs.next()){
	        	result+="<tr>";
	        	 for(int i = 1; i <= columnsNumber; i++){
	        		 result+="<td>"+rs.getObject(i)+"</td>";
	        	 }
	        	 result+="</tr>";
	        }
	        System.out.println("this is result"+result);
	        if(result.length()<36)
	        	return "There is no data for this question. <br/>";
	        
	        return result;
	        }catch(Exception e){
	        	System.out.println("error in stmt creation");
	        	e.printStackTrace();
	        	return "error in stmt creation";
	        }
	    } else {
	        System.out.println("Failed to make connection!");
	        return "failed to make connection";
	    }
		
		
		
	}
	
	
	@RequestMapping(value = "/insertData", method = RequestMethod.POST)
	public int  insertResources(@RequestParam("appName") String appName, @RequestParam("answer") String answer,@RequestParam("question") String question) throws IOException {
		
		
		System.out.println("insertData"+appName+" "+answer+" "+question+" ");
		JsonObject innerObject = new JsonObject();
		innerObject.addProperty("question", question);
		innerObject.addProperty("answer", answer);
		
		
		
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		HttpEntity entity = new NStringEntity(innerObject.toString(), ContentType.APPLICATION_JSON);

        Response indexResponse = restClient.performRequest("POST", "/" + "chatbot_new" + "/" + appName,
                Collections.<String, String>emptyMap(), entity);

        return indexResponse.getStatusLine().getStatusCode(); 
		
		
	}
	
	
	
	@RequestMapping(value = "/showData", method = RequestMethod.GET)
	public String showResources(@RequestParam("appName") String appName) throws IOException {
		//String str= 
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		//String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";
		//String body = "{ \"size\": 5, \"query\": { \"match\": { \"_all\": { \"query\": \""+query+"\", \"operator\": \"and\" } } } }";
		String body="";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response = restClient.performRequest("POST", "/chatbot_new/"+appName+"/_search?size=1000", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		return result;
	}
	
	@RequestMapping(value = "/searchData", method = RequestMethod.POST)
	public String getSearchData(@RequestParam("appName") String appName,@RequestParam("id") String id) throws IOException {
		//String str= 
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		//String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";
		//String body = "{ \"size\": 5, \"query\": { \"match\": { \"_all\": { \"query\": \""+query+"\", \"operator\": \"and\" } } } }";
		String body="{\"query\": {\"terms\": {\"_id\":  [\""+id+"\"]}}}";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response = restClient.performRequest("POST", "/chatbot_new/"+appName+"/_search?size=10", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		return result;
	}
	
	
	@RequestMapping(value = "/deleteData", method = RequestMethod.POST)
	public String deleteData(@RequestParam("appName") String appName,@RequestParam("id") String id) throws IOException {
		//String str= 
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		//String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";
		//String body = "{ \"size\": 5, \"query\": { \"match\": { \"_all\": { \"query\": \""+query+"\", \"operator\": \"and\" } } } }";
		//String body="{\"query\": {\"terms\": {\"_id\":  [\""+id+"\"]}}}";
		String body="";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response = restClient.performRequest("DELETE", "/chatbot_new/"+appName+"/"+id, Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		return result;
	}
	
	@RequestMapping(value = "/modifyData", method = RequestMethod.POST)
	public int modifyData(@RequestParam("appName") String appName,@RequestParam("id") String id,@RequestParam("jsonObj") String json) throws IOException {
		//String str= 
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		//String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";
		//String body = "{ \"size\": 5, \"query\": { \"match\": { \"_all\": { \"query\": \""+query+"\", \"operator\": \"and\" } } } }";
		//String body="{\"query\": {\"terms\": {\"_id\":  [\""+id+"\"]}}}";
		//String body="";
		
		HttpEntity entity = new NStringEntity(json, ContentType.APPLICATION_JSON);

        Response indexResponse = restClient.performRequest("POST", "/" + "chatbot_new" + "/" + appName+"/"+id,
                Collections.<String, String>emptyMap(), entity);

        return indexResponse.getStatusLine().getStatusCode(); 
		
	}
	@RequestMapping(value = "/suggestWords", method = RequestMethod.POST)
	public String suggestWords(@RequestParam("appName") String appName,@RequestParam("word") String word) throws IOException {
		//String str= 
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		/*String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";*/
		
		String queryword="";
		String body="{ \"suggest\" : { \"suggestwords\" : { \"text\" : \""+word+"\",\"term\" : { \"field\" : \"question\"}}}}";
		//String body = "{ \"size\": 5, \"query\": { \"match\": { \"_all\": { \"query\": \""+query+"\", \"operator\": \"and\" } } } }";
		//String body="{\"query\": {\"terms\": {\"_id\":  [\""+id+"\"]}}}";
		//String body="";
		
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);

        Response indexResponse = restClient.performRequest("POST", "/" + "chatbot_new" + "/" + appName+"/_search",
                Collections.<String, String>emptyMap(), entity);
        String result = EntityUtils.toString(indexResponse.getEntity());
		restClient.close();
		
		JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(result);
		
		String answer="";
			JsonObject jobj=(JsonObject)jo.get("suggest");
			JsonArray jarr=(JsonArray)jobj.get("suggestwords");
			if(jarr.size()>0){
				jobj=(JsonObject)jarr.get(0);
				jarr=(JsonArray)jobj.get("options");
				return jarr.toString();
			}
				/*for(int i=0;i<jarr.size();i++){
					JsonObject tmp=(JsonObject)jarr.get(i);
					answer+="<li class='show' id='"+i+"' style='cursor: pointer; cursor: hand;' value='"+tmp.get("text").toString().replaceAll("\"", "")+"'><h5>"+tmp.get("text").toString().replaceAll("\"", "")+"</h5></li>";
					System.out.println(tmp.get("text").toString());
				}
			}*/
		return answer;
		
		
	}
	
	
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public User authenticate(@RequestParam("username") String username,@RequestParam("password") String password) throws IOException {
	try {
		
		LdapContext conn = LDAPUtil.getConnection(username, password);
		
		User new_user=new User();
		LDAPUtil user = LDAPUtil.getUser(username, conn);
		
		
		String ans="";
		ans+="Common Name: "+user.getCommonName();
		ans+="</br>Distinguished Name: "+user.getDistinguishedName();
		ans+="</br>Given Name: "+user.getGivenName();
		ans+="</br>User Principle: "+user.getUserPrincipal();
		ans+="</br>User Name: "+user.getUserName();
		
		
		System.out.println("User common name = "+user.getCommonName());
		System.out.println("User distinguised name = "+user.getDistinguishedName());
		System.out.println("User principle = "+user.getUserPrincipal());
		System.out.println("User Given Name = "+user.getGivenName());
		System.out.println("User Name = "+user.getUserName());
		
		conn.close();
		System.out.println("Success!");
		return new_user;
	} catch(Exception e) {
		//Failed to authenticate user or change password...
		e.printStackTrace();
		return new User("-1");
		
	}
	
	}
	
	
	@RequestMapping(value = "/authenticateUser", method = RequestMethod.POST)
	public String authenticateUser(@RequestParam("username") String username) throws IOException {
		System.out.println(username);
		String ans="";
		try {
			LdapContext conn = LDAPUtil.getConnection("ban63230", "dhiraj@123");
			LDAPUtil user = LDAPUtil.getUser(username, conn);
			//System.out.println("USER CHECKED"+username);
			try{
				
				if(user.getUserName()!=null){
					return "Success";
				}
				
			}catch(Exception e){
				return "Failed";
			}
						
			conn.close();
			System.out.println("Success!");
			return "Success";
		} catch(Exception e) {
			//Failed to authenticate user or change password...
			e.printStackTrace();
			return "Failed";
		}
		
		
	}
	
	
	
	@RequestMapping(value = "/insertJson", method = RequestMethod.POST)
	public String  insertJsonResources(@RequestParam("appName") String appName, @RequestParam("jsonObj") String json) throws IOException {
		
		System.out.println(json.toString());
		
		RestClient restClient = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		
		HttpEntity entity = new NStringEntity(json, ContentType.APPLICATION_JSON);

        Response indexResponse = restClient.performRequest("POST", "/" + "chatbot_new" + "/" + appName,
                Collections.<String, String>emptyMap(), entity);
        HttpEntity ent = indexResponse.getEntity();
        String responseBody = EntityUtils.toString(ent,"UTF-8");
        System.out.println("Body----------"+responseBody);
        JsonParser parser = new JsonParser();
        Gson gson = new Gson();
        JsonObject obj = parser.parse(responseBody).getAsJsonObject();
        System.out.println(obj.toString());
        
        String id = obj.get("_id").toString();
        return indexResponse.getStatusLine().getStatusCode()+"#"+id; 
		
		
	}
	
	
	
	/*  end added by dipu  */
	
	
	
	
	
	
}
