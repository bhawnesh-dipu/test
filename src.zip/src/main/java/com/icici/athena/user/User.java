package com.icici.athena.user;
import java.util.Map;

import oracle.sql.TIMESTAMP;
public class User {

	private String user_id;
	private String user_name;
	private TIMESTAMP login_time;
	private String is_locked;
	private TIMESTAMP lock_time;
	private String is_superuser;
	private String role_id;
	private String manager_id;
	private Map<String,String> grant;
	
	public User(){
		
	}
	public User(String user_id){
		this.user_id=user_id;
		
	}
	public User(String user_id,String user_name){
		this.user_id=user_id;
		this.user_name=user_name;
		
		
	}
	public User(String user_id,String user_name,TIMESTAMP login_time){
		this.user_id=user_id;
		this.user_name=user_name;
		this.login_time=login_time;
		
	}
	
	
	
	
	public User(String user_id, String user_name, TIMESTAMP login_time, String is_locked, String is_superuser,
			String role_id) {
		super();
		this.user_id = user_id;
		this.user_name = user_name;
		this.login_time = login_time;
		this.is_locked = is_locked;
		this.is_superuser = is_superuser;
		this.role_id = role_id;
	}
	public User(String user_id, String user_name, TIMESTAMP login_time, String is_locked, String is_superuser,
			String role_id,String manager_id,Map<String,String> grant) {
		super();
		this.user_id = user_id;
		this.user_name = user_name;
		this.login_time = login_time;
		this.is_locked = is_locked;
		this.is_superuser = is_superuser;
		this.role_id = role_id;
		this.manager_id=manager_id;
		this.grant=grant;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public TIMESTAMP getLogin_time() {
		return login_time;
	}
	public void setLogin_time(TIMESTAMP login_time) {
		this.login_time = login_time;
	}
	public String getIs_locked() {
		return is_locked;
	}
	public void setIs_locked(String is_locked) {
		this.is_locked = is_locked;
	}
	public String getIs_superuser() {
		return is_superuser;
	}
	public void setIs_superuser(String is_superuser) {
		this.is_superuser = is_superuser;
	}
	public String getRole_id() {
		return role_id;
	}
	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}
	public User getUser(String id){
		if(id.equals(this.user_id)){
			return this;
		}else {
			return new User(id);
		}
	}
	public String getManager_id() {
		return manager_id;
	}
	public void setManager_id(String manager_id) {
		this.manager_id = manager_id;
	}
	public TIMESTAMP getLock_time() {
		return lock_time;
	}
	public void setLock_time(TIMESTAMP lock_time) {
		this.lock_time = lock_time;
	}
	public Map<String,String> getGrant() {
		return grant;
	}
	public void setGrant(Map<String,String> grant) {
		this.grant = grant;
	}




//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
