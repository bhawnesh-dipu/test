package com.icici.athena.ldap;

import static javax.naming.directory.SearchControls.SUBTREE_SCOPE;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*import co.in.hayagreeva.utils.ErrorUtils;
import co.in.hayagreeva.utils.HelperUtils;
*/
public class LDAPUtil {
	private static final transient Logger logger = LoggerFactory.getLogger(LDAPUtil.class);
	private String distinguishedName;
	private String userPrincipal;
	private String commonName;
	private String givenName;
	private String userName;
	private static String[] userAttributes = { "distinguishedName", "cn", "name", "uid", "sn", "givenname", "memberOf",
			"samaccountname", "userPrincipalName" };
	private String SESSION_ATTRIBUTE = "session.user";

	private HttpSession session;

	public LDAPUtil() {
	}

	public LDAPUtil(HttpSession session) {
		this.session = session;
	}

	public LDAPUtil(Attributes attr) throws javax.naming.NamingException {
		userPrincipal = (String) attr.get("userPrincipalName").get();
		commonName = (String) attr.get("cn").get();
		distinguishedName = (String) attr.get("distinguishedName").get();
		givenName = (String) attr.get("givenname").get();
		userName = (String) attr.get("name").get();

	}

	/**
	 * Get the User Name from Session
	 * 
	 * @return Session User Name
	 */
	public String getSession() {
		String userName = (String) session.getAttribute(SESSION_ATTRIBUTE);
		return userName;
	}

	/**
	 * Set User Name to Session
	 * 
	 * @param userName
	 */
	public void setSession(String userName) {
		session.setAttribute(SESSION_ATTRIBUTE, userName);
	}

	public String getUserPrincipal() {
		return userPrincipal;
	}

	public String getCommonName() {
		return commonName;
	}

	public String getGivenName() {
		return givenName;
	}

	public String getUserName() {
		return userName;
	}

	public String getDistinguishedName() {
		return distinguishedName;
	}

	public String toString() {
		return getDistinguishedName();
	}

	/**
	 * Used to authenticate a user given a username/password. Domain name is
	 * derived from the fully qualified domain name of the host machine.
	 * 
	 * @param username
	 * @param password
	 * @return
	 * @throws NamingException
	 */
	public static LdapContext getConnection(String username, String password) throws NamingException {
		// HelperUtils.logDebug(new StringBuilder(" [getConnection] Init"),
		// logger);
		return getConnection(username, password, null, null);
	}

	/**
	 * Used to authenticate a user given a username/password and domain name.
	 * 
	 * @param username
	 * @param password
	 * @param domainName
	 * @return LDAP Context Object
	 * @throws NamingException
	 */
	public static LdapContext getConnection(String username, String password, String domainName)
			throws NamingException {
		// HelperUtils.logDebug(new StringBuilder(" [getConnection] Init"),
		// logger);
		return getConnection(username, password, domainName, null);
	}

	/**
	 * Used to authenticate a user given a username/password and domain name.
	 * Provides an option to identify a specific LDAP server.
	 * 
	 * @param username
	 * @param password
	 * @param domainName
	 * @param serverName
	 * @return LDAP Context Object
	 * @throws NamingException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static LdapContext getConnection(String username, String password, String domainName, String serverName)
			throws NamingException {
		// HelperUtils.logDebug(new StringBuilder(" [getConnection] Enter"),
		// logger);
		if (domainName == null) {
			try {
				String fqdn = java.net.InetAddress.getLocalHost().getCanonicalHostName();
				if (fqdn.split("\\.").length > 1)
					domainName = fqdn.substring(fqdn.indexOf(".") + 1);
			} catch (java.net.UnknownHostException e) {
			}
		}

		if (password != null) {
			password = password.trim();
			if (password.length() == 0)
				password = null;
		}

		// bind by using the specified username/password
		Hashtable props = new Hashtable();
		String principalName = username + "@" + domainName;
		// HelperUtils.logDebug(new StringBuilder(" [getConnection]
		// principalName = ").append(principalName), logger);

		props.put(Context.SECURITY_PRINCIPAL, principalName);
		if (password != null)
			props.put(Context.SECURITY_CREDENTIALS, password);

		// String ldapURL = "ldap://" + ((serverName==null)? domainName :
		// serverName + "." + domainName) + '/';
		String ldapURL = "ldap://10.50.37.171:3268/";
		// HelperUtils.logDebug(new StringBuilder(" [getConnection] ldapURL =
		// ").append(ldapURL), logger);

		props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		props.put(Context.PROVIDER_URL, ldapURL);
		try {
			// HelperUtils.logDebug(new StringBuilder(" [getConnection] Exit"),
			// logger);
			System.out.println("After connecting to the LDAP server-------------------"+props.toString());
			return new InitialLdapContext(props, null);
		} catch (javax.naming.CommunicationException e) {
			// ErrorUtils.logError(logger, "Failed to connect to " + domainName
			// + ((serverName==null)? "" : " through " + serverName));
			return null;
		} catch (NamingException e) {
			// ErrorUtils.logError(logger, "Failed to authenticate " + username
			// + "@" + domainName + ((serverName==null)? "" : " through " +
			// serverName));
			return null;
		}
	}

	/**
	 * Used to check whether a username is valid.
	 * 
	 * @param username
	 *            (e.g. "peter", "peter@acme.com" or "ACME\peter")
	 * @param context
	 * @return LDAP User
	 */
	public static LDAPUtil getUser(String username, LdapContext context) {
		// HelperUtils.logDebug(new StringBuilder(" [getUser] Enter"), logger);
		try {
			System.out.println("UserName:"+username+"Context:"+context.toString());
			String domainName = null;
			if (username.contains("@")) {
				username = username.substring(0, username.indexOf("@"));
				domainName = username.substring(username.indexOf("@") + 1);
			} else if (username.contains("\\")) {
				username = username.substring(0, username.indexOf("\\"));
				domainName = username.substring(username.indexOf("\\") + 1);
			} else {
				
				String authenticatedUser = (String) context.getEnvironment().get(Context.SECURITY_PRINCIPAL);

				if (authenticatedUser.contains("@")) {
					domainName = authenticatedUser.substring(authenticatedUser.indexOf("@") + 1);
					// HelperUtils.logDebug(new StringBuilder(" [getUser]
					// domainName = ").append(domainName), logger);
				}
			}

			if (domainName != null) {
				String principalName = username + "@" + domainName;
				// HelperUtils.logDebug(new StringBuilder(" [getUser]
				// principalName = ").append(principalName), logger);

				SearchControls controls = new SearchControls();
				controls.setSearchScope(SUBTREE_SCOPE);
				controls.setReturningAttributes(userAttributes);
				NamingEnumeration<SearchResult> answer = context.search(toDC(domainName),
						"(& (userPrincipalName=" + principalName + ")(objectClass=user))", controls);
				if (answer.hasMore()) {
					Attributes attr = answer.next().getAttributes();
					Attribute userAttr = attr.get("userPrincipalName");
					if (userAttr != null)
						return new LDAPUtil(attr);
				}
			}
		} catch (NamingException e) {
			// ErrorUtils.logError(logger, "ERROR While Authenticating User : "
			// +e);
		}
		// HelperUtils.logDebug(new StringBuilder(" [getUser] Exit"), logger);
		return null;
	}

	/**
	 * Returns a list of users in the domain.
	 * 
	 * @param context
	 * @return LDAP User List
	 * @throws NamingException
	 */
	@SuppressWarnings("rawtypes")
	public static LDAPUtil[] getUsers(LdapContext context) throws NamingException {
		// HelperUtils.logDebug(new StringBuilder(" [getUsers] Enter"), logger);
		java.util.ArrayList<LDAPUtil> userList = new java.util.ArrayList<LDAPUtil>();
		String authenticatedUser = (String) context.getEnvironment().get(Context.SECURITY_PRINCIPAL);
		if (authenticatedUser.contains("@")) {
			String domainName = authenticatedUser.substring(authenticatedUser.indexOf("@") + 1);
			SearchControls controls = new SearchControls();
			controls.setSearchScope(SUBTREE_SCOPE);
			controls.setReturningAttributes(userAttributes);
			NamingEnumeration answer = context.search(toDC(domainName), "(objectClass=user)", controls);
			try {
				while (answer.hasMore()) {
					Attributes attr = ((SearchResult) answer.next()).getAttributes();
					Attribute userAttr = attr.get("userPrincipalName");
					if (userAttr != null) {
						userList.add(new LDAPUtil(attr));
					}
				}
			} catch (Exception e) {
				System.out.println("Error while fetching users:" + e);
				// ErrorUtils.logError(logger, "ERROR While Fetching Users : "
				// +e);
			}
		}
		// HelperUtils.logDebug(new StringBuilder(" [getUsers] Exit"), logger);
		for (LDAPUtil u : userList) {
			System.out.println(u.getUserName());
		}
		return userList.toArray(new LDAPUtil[userList.size()]);
	}

	/**
	 * Give the Domain name (eg: icicibankltd.com)
	 * 
	 * @param domainName
	 * @return Domain Name
	 */
	private static String toDC(String domainName) {
		// HelperUtils.logDebug(new StringBuilder(" [toDC] Enter"), logger);
		StringBuilder buf = new StringBuilder();
		for (String token : domainName.split("\\.")) {
			if (token.length() == 0)
				continue; // defensive check
			if (buf.length() > 0)
				buf.append(",");
			buf.append("DC=").append(token);
		}
		// HelperUtils.logDebug(new StringBuilder(" [toDC] Exit"), logger);
		return buf.toString();
	}

	/* added by dipu */
	public void getUserByIp( String userAddress) throws NamingException {
		// Replace with your context and domain name
		String userContext = "cn=Users,dc=your,dc=icicibankltd,dc=com";
		LdapContext ctx =LDAPUtil.getConnection("ban63230", "dhiraj@123");
		String filter = "(&(objectClass=inetOrgPerson)(networkAddress=" + userAddress + "))";
		// You are trying to find a single user, so set the controls to return
		// only on instance
		SearchControls contr = new SearchControls();
		contr.setCountLimit(1L);
		try {
			NamingEnumeration<SearchResult> results = ctx.search(userContext, filter, contr);
			if (results.hasMore()) {
				while (results.hasMore()) {
					// User found
					SearchResult user = results.next();
				}
			} else {
				// No user found
			}
		} catch (NamingException e) {
			// If there is more than one result, this error will be thrown from
			// the while loop
		}
	}
	/*
	 * public static void main(String args[]) { try { LdapContext conn =
	 * LDAPUtil.getConnection("ban63230", "dhiraj@123"); LDAPUtil user =
	 * LDAPUtil.getUser("ban63230", conn);
	 * System.out.println("User common name = "+user.getCommonName());
	 * System.out.println("User distinguised name = "+user.getDistinguishedName(
	 * )); System.out.println("User principle = "+user.getUserPrincipal());
	 * System.out.println("User Given Name = "+user.getGivenName());
	 * System.out.println("User Name = "+user.getUserName());
	 * 
	 * conn.close(); System.out.println("Success!"); } catch(Exception e) {
	 * //Failed to authenticate user or change password... e.printStackTrace();
	 * } }
	 */
}
