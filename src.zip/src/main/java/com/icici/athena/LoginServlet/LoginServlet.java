package com.icici.athena.LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.naming.ldap.LdapContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icici.athena.controller.UserController;
import com.icici.athena.ldap.LDAPUtil;
import com.icici.athena.user.User;

import ch.qos.logback.core.net.SyslogOutputStream;

/**
 * Servlet implementation class LoginServlet
 */

@Controller
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private  String username = "admin";
	private  String password = "password";
	private String userid="BAN0000000";
	@ResponseBody
	@RequestMapping(value = "/LoginServlet")
	public  void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		userid=request.getParameter("username");
		password=request.getParameter("password");
		try{
			LdapContext conn = LDAPUtil.getConnection(userid,password);
			LDAPUtil user =null;
			try{
			user = LDAPUtil.getUser(userid, conn);
			}catch(Exception e){
				System.out.println("Your EmployeeId might be locked !!!!");
			}
			User curr_user=new User();
			String user_principle=user.getUserPrincipal();
			curr_user.setUser_id(user_principle.substring(0,user_principle.indexOf("@")));
			curr_user.setUser_name(user.getUserName());
			username=curr_user.getUser_name();
			System.out.println(username);
			System.out.println("User common name = "+user.getCommonName());
			System.out.println("User distinguised name = "+user.getDistinguishedName());
			System.out.println("User principle = "+user.getUserPrincipal());
			System.out.println("User Given Name = "+user.getGivenName());
			System.out.println("User Name = "+user.getUserName());
			
			
			try{
			HttpSession session = request.getSession(true);
			session.setAttribute("username", curr_user.getUser_name());
			session.setAttribute("userid", curr_user.getUser_id());
			session.setAttribute("ipaddress", request.getRemoteAddr());
			session.setAttribute("sessionid", request.getSession().getId());
			
			
			
			
			//setting session to expiry in 30 mins
			session.setMaxInactiveInterval(5*60);
			Cookie userName = new Cookie("username", URLEncoder.encode(username, "UTF-8"));
			userName.setMaxAge(5*60);
			response.addCookie(userName);
			response.sendRedirect("/admin");
			}catch(Exception e){
				System.out.println("ERROR in SESSION"+e);
			}

		}catch(Exception e){
			System.out.println(e);
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/login");
			PrintWriter out= response.getWriter();
			out.println("<font color=red>Either user name or password is wrong.</font>");
			rd.include(request, response);
		}

	}

}