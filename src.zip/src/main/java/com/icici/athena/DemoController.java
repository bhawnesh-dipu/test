package com.icici.athena;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.icici.athena.controller.AjaxController;

@Controller
public class DemoController {
	@RequestMapping("/")
	String reload(){
		return "default";
	}	
	@RequestMapping(value="/Chat", method = RequestMethod.GET)
	String index(HttpServletRequest request) throws IOException{
		
		AjaxController.log("", "", "", "", "", "Accessing Chat Page", request);
		return "index";
	}	
	
	
	@RequestMapping("/search")
	String search(){
		return "search";
	}
	@RequestMapping("/insert")
	String insert(){
		return "insert";
	}	
	@RequestMapping("/show")
	String show(){
		return "show";
	}	
	@RequestMapping("/delete")
	String delete(){
		return "delete";
	}
	@RequestMapping("/modify")
	String modify(){
		return "modify";
	}
	@RequestMapping("/admin")
	String admin(){
		return "admin";
	}
	@RequestMapping("/login")
	String login(){
		return "login";
	}
	@RequestMapping("/help")
	String help(){
		return "help";
	}
	/*
	@RequestMapping("/faq-management")
	String faq(){
		return "faq-management";
	}*/
	
	@RequestMapping("/subject-area")
	String subject(){
		return "subject-area";
	}
	
	@RequestMapping("/user-management")
	String user(){
		return "user-management";
	}
	@RequestMapping("/grant-management")
	String grant(){
		return "grant-management";
	}
	@RequestMapping("/role-management")
	String role(){
		return "role-management";
	}
	@RequestMapping("/fileupload")
	String fileupload(){
		return "fileupload";
	}
	

}
