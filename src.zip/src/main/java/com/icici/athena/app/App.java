package com.icici.athena.app;
import oracle.sql.TIMESTAMP;

public class App {
	private String app_id;
	private String app_name;
	private String user_id;
	private String user_name;
	private TIMESTAMP created_date;
	
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public App(){
		
	}
	
	public App(String app_id, String app_name, String user_id, String user_name, TIMESTAMP created_date) {
		
		this.app_id = app_id;
		this.app_name = app_name;
		this.user_id = user_id;
		this.user_name = user_name;
		this.created_date = created_date;
	}
	public String getApp_id() {
		return app_id;
	}



	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}



	public String getApp_name() {
		return app_name;
	}



	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}





	public TIMESTAMP getCreated_date() {
		return created_date;
	}



	public void setCreated_date(TIMESTAMP TIMESTAMP) {
		this.created_date = TIMESTAMP;
	}



/*	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
*/
}
