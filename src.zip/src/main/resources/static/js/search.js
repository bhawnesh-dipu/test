function searchData(){
	var appName=$('#appName').val().toString().trim();
	var query=$('#search_box').val().toString().trim();
	$('#result').html(' ');
	    		$.ajax({
	    			type:"GET",
	    			url: "/searchQuery",
	    			data : {"appName" : appName,
	    					"q":query
	    					},
	    			success : function(res){
	    				console.log(res);
	    				
	    				console.log("res=:"+res);
						var qa = JSON.parse(res);
						console.log("qa:"+qa.hits.hits.length);
						console.log(qa.hits.hits);
						var table="<table class='table table-striped table-bordered table-hover'><thead><tr><td>No.</td><td>ID</td><td>Type </td><td>Question</td><td>Action</td></tr></thead><tbody>";
						result = null;
						result = qa.hits.hits;
						var i=1;
						qa.hits.hits.forEach(function(entry) {
							
							console.log("source:"+entry._source.question);
							
							table+="<tr><td>"+i+"</td><td>"+entry._id+"</td><td>"+entry._type+"</td><td>"+entry._source.question+"</td><td><a href='./modify?id="+entry._id+"&appName="+entry._type+"' class='btn btn-warning'>Modify</a>"+"<a href='./delete?id="+entry._id+"&appName="+entry._type+"' class='btn btn-danger'>Delete</a>"+"</td></tr>";
							
						i=i+1;
							
						});
						table+="</tbody></table>";
						$('#databody').html(table);
						//$('#alerttext').html("<h3 class='alert alert-success'>Success Loading..</h3>");
						
					},
					error : function(res) {
						console.log("fail");
						$('#alerttext').html("<h3 class='alert alert-danger'>Error Searching data..</h3>");
						
					}
	    	});// end of ajax
	    	
}
function onResult(id){
	var t=$(id).html();
	t=t.replace('<h5>','');
	t=t.replace('</h5>','');
	t=t.trim();
	//alert(t);
	console.log(t+$('#search_box').val());
$('#search_box').val(t);
}



function liveSearchData(){
	var appName=$('#appName').val().toString().trim();

	var value = $('#search_box').val().toString().trim();
	

	
	console.log(value);
	$.ajax({
		type : "GET",
		url : "/searchQuery",
		data : {"appName" : appName,
			"q" : value
		},
		success : function(res) {
			console.log("res=:"+res);
			var qa = JSON.parse(res);
			console.log("qa:"+qa.hits.hits.length);
			console.log(qa.hits.hits);
			$("#result li").remove();
			result = null;
			result = qa.hits.hits;
			var i=0;
			qa.hits.hits.forEach(function(entry) {
				$("#result").show();
				console.log("source:"+entry._source.question);
				//if(entry._source.question){
				$("#result").append(
						"<li class='show' id='"+i+"' style='cursor: pointer; cursor: hand;border: 1px solid blue;' onclick='onResult(this);'><h5>" + entry._source.question
								+ "</h5></li>");
				
				i=i+1;
				//}
			});
		},
		error : function(res) {
			console.log("fail");
			//sendMessage("Not enough data");
		}
	
	});
	    	
}