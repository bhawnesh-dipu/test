function check(){
	var username=$('#username').val().toString().trim();
	//alert("check");
	$.ajax({
			type:"POST",
			url: "/authenticateUser",
			data : {"username" : username
					},
			success : function(res){
				if(res==='Success'){
					$('#alerttext').removeClass('alert-danger').addClass('alert-success');
					$('#alerttext').html("Valid User");
					$('#passDiv').removeAttr("hidden");
					$('#login_btn').attr("onclick","login();");
				}else{
					$('#alerttext').removeClass('alert-success').addClass('alert-danger');
					$('#alerttext').html("Not a Valid User!!!");
				}
			},error:function(res){
				$('#alerttext').removeClass('alert-success').addClass('alert-danger').html("Error");
				
			}
	});
}

function login(){ 
	//alert("login");
			var username=$('#username').val().toString().trim();
			var password=$('#password').val().toString().trim();
			console.log(username+"-----------"+password);
			$.ajax({
	    			type:"POST",
	    			url: "/LoginServlet",
	    			data : {"username" : username,
	    					"password" : password
	    					
	    					},
	    			success : function(res){
	    				console.log(res);
	    				UserActivitylog(username.toUpperCase(),"LOGIN");
	    				location.replace('/admin');	    			
	    			},error:function(res){
	    				console.log(res);
	    				$('#alerttext').removeClass('alert-success').addClass('alert-danger');
						$('#alerttext').html("username or password incorrect!!!");
						$('#password').val('');

						$('#passDiv').attr("hidden","hidden");
						$('#login_btn').attr("onclick","check();");
	    				
	    			}
});
}

function logout(){ 
	//alert("logout");
			$.ajax({
	    			type:"POST",
	    			url: "/LogoutServlet",
	    			data : {},	    					
	    			success : function(res){
	    				console.log(res);
	    				
	    				UserActivitylog($('#userid').attr('value'),"LOGOUT",$('#sessionid').val().toString().trim());
	    				location.replace('/login');	    			
	    			},error:function(res){
	    				$('#alerttext').html(res);
	    				
	    			}
});
};