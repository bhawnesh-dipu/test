$(document).ready(function(){

  $(".message_input ").keyup(function(){
  	if($(".upper_results li").length > 1){
  		$(".upper_results.dropup").css("display","block");
  		$(".results").css("bottom","92px");
  	} else{
  		$(".upper_results.dropup").css("display","none");
 		$(".results").css("bottom","57px");
  	}
  });
  
});