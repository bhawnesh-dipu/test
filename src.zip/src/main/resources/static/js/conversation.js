
function encode(s){
	s=s.toString();
	s=s.replace(/"/g,'#&dblq');
	s=s.replace(/'/g,'#&snglq');
	return s;
}
function decode(s){
	s=s.toString();
	s=s.replace(/#&dblq/g,'"');
	s=s.replace(/#&snglq/g,'\'');
	return String(s);
}

function startConversation(ans){
	
	////alert("starting conversation:"+JSON.stringify(ans));
	ans=encode(JSON.stringify(ans));
	$('#jsondata').val(ans);
	startChat(ans);
}
function startChat(da){
	//alert("start chat");
	var path=$('#jsondatapath').val();
	var data=$('#jsondata').val();
	data=decode(data);
	//alert("start chat -->after decode data"+data);
	data=JSON.parse(data);
	////alert(data);
	console.log("data-------->"+data);
	
	//alert("length-->"+data.length);
	console.log("length-->"+data.length);
	
	
		//alert("all--->");
	
		
		if(data.constructor === Array){
			
			console.log("in if");
			console.log(data);
			var questions=new Array();
			var resp="";
			for(var i=0;i<data.length;){
				if(data[i].hasOwnProperty('answer') && data[i].hasOwnProperty('conv_ans')){
					sendMessage(data[i].answer,1);
        			log($("#AppNameSelect").val(),"CLICK ON LINK ",data[i].answer,"NULL","NULL","CONV_CHAT_ANSWER");	
        			console.log("data---->"+data[i].conv_ans[i].question.toString());
					console.log(data[i].conv_ans.length);
					
					resp='';
					for(var k=0;k<data[i].conv_ans.length;k++){
						questions.push(data[i].conv_ans[k].question);
						resp+="<li>" +
								"<h5>" +
								"<button class='suggestion btn btn-responsive' id='myanswer'  onclick='getMyAnswer(this);'" +
									" value='"+encode(JSON.stringify(data[i].conv_ans[k]))+"'>"+(k+1)+".&nbsp;"+data[i].conv_ans[k].question +
								"</button>"+
								"</h5>"+
							"</li>";
	        			log($("#AppNameSelect").val(),"CLICK ON LINK ",data[i].conv_ans[k].question,"NULL","NULL","CONV_CHAT_SUGGESTIONS");	

					}
					i++;
				}else{
					console.log("else "+data[i].question+"  i::"+i);
					questions.push(data[i].question);
					resp+="<li><h5><button class='suggestion btn btn-responsive' id='myanswer' onclick='getMyAnswer(this);' value='"+encode(JSON.stringify(data[i]))+"'>"+(i+1)+".&nbsp;"+data[i].question+"</button></h5></li>";
        			log($("#AppNameSelect").val(),"CLICK ON LINK ",data[i].question,"NULL","NULL","CONV_CHAT_SUGGESTIONS");	

					i++;
				}
				
				
			}
			sendMessage(resp,1);
		}else{
			console.log("in else");
			console.log(data.answer+"====================================================");
			//sendMessage(data.answer,1);
		}
	
	
}
function getMyAnswer(id){
	////alert("get my answer--->"+$(id).val());
	var jsond=($(id).val());
		jsond=decode(jsond);
		jsond=JSON.parse(jsond);
		
	
	if(jsond.hasOwnProperty('answer') && jsond.hasOwnProperty('question')){
		//alert("all");
		sendMessage(jsond.question,2);
		sendMessage(jsond.answer,1);
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CONV_CHAT_QA");
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_END");	
    	

	}else if(jsond.hasOwnProperty('question') && jsond.hasOwnProperty('conv_ans')){
		
		sendMessage(jsond.question,2);
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	

		startConversation(jsond.conv_ans);
	}
}