$(document).ready(function(){
	$.urlParam = function(name){
	    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
	    if (results==null){
	       return null;
	    }
	    else{
	       return decodeURI(results[1]) || 0;
	    }
	}
	$('#id').val($.urlParam('id'));
	var appName=$.urlParam('appName');
	$('#appName option[value="'+appName+'"]').prop('selected', true)
});



var question="";


function searchData(){
	var appName=$('#appName').val().toString().trim();
	var id=$('#id').val().toString().trim();
	    		$.ajax({
	    			type:"POST",
	    			url: "/searchData",
	    			data : {"appName" : appName,
	    					"id":id
	    					},
	    			success : function(res){
	    				console.log(res);
	    				
	    				console.log("res=:"+res);
						var qa = JSON.parse(res);
						console.log("qa:"+qa.hits.hits.length);
						console.log(qa.hits.hits);
						var table="<table class='table table-striped table-bordered table-hover'><thead><tr><td>No.</td><td>ID</td><td>Type </td><td>Question</td><td>Action></td></tr></thead><tbody>";
						result = null;
						result = qa.hits.hits;
						var i=1;
						qa.hits.hits.forEach(function(entry) {
							
							console.log("source:"+entry._source.question);
							question=entry._source.question;
							table+="<tr><td>"+i+"</td><td>"+entry._id+"</td><td>"+entry._type+"</td><td>"+entry._source.question+"</td>"+"<td><button class='btn btn-danger' onclick='deleteData();'>Delete</td></tr>";
							
						i=i+1;
							
						});
						table+="</tbody></table>";
						$('#databody').html(table);
						//$('#alerttext').html("<h3 class='alert alert-success'>Success Loading..</h3>");
						
					},
					error : function(res) {
						console.log("fail");
						$('#alerttext').html("<h3 class='alert alert-danger'>Error Deleting data.. Error  Please check ID and Application..</h3>");
						
					}
	    	});// end of ajax
	    	
}



function deleteData(){
	var appName=$('#appName').val().toString().trim();
	var id=$('#id').val().toString().trim();
	    		$.ajax({
	    			type:"POST",
	    			url: "/deleteData",
	    			data : {"appName" : appName,
	    					"id":id
	    					},
	    			success : function(res){
	    				//console.log(res);
	    				
	    				console.log("res=:"+res);
	    				
	    				//var id=res.substring(res.search('#')+2,res.length-1);
						//console.log(id);
						Activitylog(appName,question,"DELETE",id);
	    				
						var qa = JSON.parse(res);
						var result=qa.result;
						
						$('#databody').html(result);
						$('#alerttext').html("<h3 class='alert alert-success'>"+result+"</h3>");
						
					},
					error : function(res) {
						console.log("fail");
						$('#alerttext').html("<h3 class='alert alert-danger'>Error inserting data..</h3>");
						
					}
	    	});// end of ajax
	    	
}