$(document).ready(
		function() {
			$.urlParam = function(name) {
				var results = new RegExp('[\?&]' + name + '=([^&#]*)')
						.exec(window.location.href);
				if (results == null) {
					return null;
				} else {
					return decodeURI(results[1]) || 0;
				}
			}
			$('#id').val($.urlParam('id'));
			var appName = $.urlParam('appName');
			$('#appName option[value="' + appName + '"]')
					.prop('selected', true)
		});

/*----------------------------------------------------------*/
function toJson(id, filename, i) {

	
	console.log("i---->" + i);
	console.log(filename);

	console.log("id:" + id);
	var children = id.childNodes;
	console.log(children);
	
	children.forEach(function(item) {
			
			if (item.nodeName.toLowerCase() === 'li') {
				var json = {};
				var q = 0;
				var a = 0;
				var que = '';
				var ans = '';
				var assign=0;
				var arr=[];
				
				var ul=0;
				console.log("start of loop ");
				console.log(json);
				console.log(item);
					child1 = item.childNodes;
					console.log(child1);
					child1.forEach(function(nextitem) {
						console.log(nextitem.nodeName.toLowerCase());
								if (nextitem.nodeName.toLowerCase() === 'div') {
									child2 = nextitem.childNodes;
									child2.forEach(function(nextnextitem) {
												if (nextnextitem.nodeName.toLowerCase() === 'div') {
													child3 = nextnextitem.childNodes;
													child3.forEach(function(nextnextnextitem) {
															if (nextnextnextitem.nodeName.toLowerCase() === 'textarea') {
																	if (nextnextnextitem.id.toLowerCase() === 'question') {
																		json.question=nextnextnextitem.value.trim();
																	} else if (nextnextnextitem.id.toLowerCase() === 'answer') {
																		json.answer=nextnextnextitem.value.trim();
																	}
																}
														});
												}
											});
								}else if (nextitem.nodeName.toLowerCase() === 'ul') {
									console.log("UL found");
									filename.conv_ans = [];
									console.log("conv_arr");
									console.log(filename);
									i++;
									json.conv_ans=[];
									var tmp={};
									tmp=toJson(nextitem, tmp, -1);
									if(Object.keys(tmp).length>0)
									arr.push(tmp);
									console.log(tmp);
									console.log("temppppp");
								
									
									filename.conv_ans=json.conv_ans;
									//console.log(JSON.stringify(filename));
									console.log(JSON.stringify(json));
									//filename.push(json);
								}
								
							});

					
				console.log("loopingg");
				console.log(json);
				console.log(filename);
				if(json.hasOwnProperty("question") && json.question.length>0)
					filename.question=json.question;
				if(json.hasOwnProperty("answer") && json.answer.length>0)	
					filename.answer=json.answer;
				if(arr.length>0)
				filename.conv_ans=arr;
			
				
			}
				
			});
	console.log(JSON.stringify(filename));
	console.log("return with i-->"+i);
return filename;
}




function getRandomColor() {
	  var letters = '0123456789ABCDEF';
	  var color = '#';
	  for (var i = 0; i < 6; i++) {
	    color += letters[Math.floor(Math.random() * 16)];
	  }
	  return color;
	}

function addQ(id, que) {

    var q = 0;
    var qparentlevel = 0;

    q = id;

var liname = '#lilevel' + q;
qlevel = q + 1;
qparentlevel = q + 1;
// alert(liname);

var question = '<div class="form-group">'
+ '<label class="control-label col-md-1 pt5" for="question">Question:</label>'
+ '<div class="col-md-11">'
+ '<textarea class="form-control" id="question" rows="1" placeholder="Enter question" required="required">'+que+'</textarea>'
+ '<input type="hidden" id="qlevel" value="'
+ qlevel
+ '"/>'
+ '<input type="hidden" id="qparentlevel" value="'
+ qparentlevel
+ '"/>'
+ '</div>'
+ '</div>'
+ '<div class="form-group">'
+ '<div class="col-sm-offset-2 col-sm-10">'
+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
+ qlevel
+ '"'
+ ' onclick="addQuestion(this);">Add Question</button>'
+ ' <button type="button" class="btn btn-primary" id="addsolution" value="'
+ qparentlevel + '"'
+ ' onclick="addSolution(this);">Add Solution</button>' 

+ ' <button type="button" class="btn btn-primary" id="addanswer" value="'
+ qparentlevel + '"'
+ ' onclick="addAnswer(this);">Add Answer</button>' 
+ '</div>'
+ '</div>';
    //console.log("Conv_ans:---");
    var ulid = '#lilevel' + qlevel;




    $('.'+id).last().children("li").last().append(question);
    console.log(liname);


}

function addA(id, ans) {
	 var q = 0;
	    var qparentlevel = 0;

	    q = id;
	    console.log("id of answer----------------" + q+id);
	    var liname = '.lilevel' + q;
	    qlevel = q;
	    qparentlevel = q;
	     //alert(liname);

	    var answer = '<div class="form-group">'
	            + '<label class="control-label col-md-1 pt5" for="question">Answer:</label>'
	            + '<div class="col-md-11">'
	            + '<textarea class="form-control" id="answer" rows="1"'
	            + 'placeholder="Enter Answer" required="required">' + ans+'</textarea>'
	            + '<input type="hidden" id="qlevel" value="' + qlevel + '"/>'
	            + '<input type="hidden" id="qparentlevel" value="' + qparentlevel
	            + '"/>' + '</div>' + '</div>';
	    console.log(liname);


	    //$('#'+id).last().children("li").children('div').first('div').after(answer);
	    $(answer).insertBefore($('.'+id).last().children("li").children('div').last());
	    $('.'+id).last().children("li").children('div').last().children('div').last().children('button').last().prop('disabled', true);
	    console.log(liname);
}

function addBoth(id, obj) {

	addQ(id, obj.question);
	addA(id, obj.answer);
}

function addS(id, sol) {

    var q = 0;
    var qparentlevel = 0;

    q = id;

var liname = '#lilevel' + q;
qlevel = q + 1;
qparentlevel = q + 1;
// alert(liname);

var solution = '<div class="form-group">'
+ '<label class="control-label col-md-1 pt5" for="solution">Solution:</label>'
+ '<div class="col-md-11">'
+ '<textarea class="form-control" id="question" rows="1" placeholder="Enter question" required="required">'+sol+'</textarea>'
+ '<input type="hidden" id="qlevel" value="'
+ qlevel
+ '"/>'
+ '<input type="hidden" id="qparentlevel" value="'
+ qparentlevel
+ '"/>'
+ '</div>'
+ '</div>'
+ '<div class="form-group">'
+ '<div class="col-sm-offset-2 col-sm-10">'
+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
+ qlevel
+ '"'
+ ' onclick="addQuestion(this);">Add Question</button>'
+ '</div>'
+ '</div>';
    //console.log("Conv_ans:---");
    var ulid = '#lilevel' + qlevel;



    $('.'+id).last().children("li").last().append(solution);
    $('.'+id).last().parent().children('div').children('div').find('#addsolution').prop('disabled','true');
    
    console.log(liname);


}

/*-----------------------------------------------------------------*/

var stack = '';

var _first = 0;
var id="lilevel0";
var divId='#data';
function init(){
	_first=0;
	id="lilevel0";
	divId="#data";
}
function jsonToHtml(id,obj) {
    console.log(obj);
    console.log('#'+id);
    if(_first===0){
        _first=1;
        $('#data').append("<ul class='"+id+"' id='"+id+"' style='border-left:2px solid #000;list-style-type:none;'></ul>");

    }else {
        var parentUl=id.substring(0,id.length-1);
        $('.' + parentUl).last().children('li').append("<ul class='" + id + "' id='" + id + "' style='border-left:2px solid #000;list-style-type:none;'></ul>");
    }
    if (obj.hasOwnProperty('question') && obj.hasOwnProperty('answer') && obj.hasOwnProperty('conv_ans')) {
        $('.'+id).last().append("<li></li>");
        console.log($('.'+id).last());
       
        addBoth(id,obj);
        for(var ele in obj.conv_ans) {
            console.log("call--->");
            jsonToHtml(id + 1, obj.conv_ans[ele]);
        }

    }else if (obj.hasOwnProperty('question') && obj.hasOwnProperty('answer')) {
        $('.'+id).last().append("<li></li>");

       
        console.log($('.'+id).last());
        addBoth(id,obj);

    } else if (obj.hasOwnProperty('question') && obj.hasOwnProperty('conv_ans')) {
        $('.'+id).last().append("<li></li>");
        console.log($('.'+id).last());

      
        addQ(id,obj.question);
        for(var ele in obj.conv_ans) {
            console.log("call::::");
            jsonToHtml(id + 1, obj.conv_ans[ele]);
        }
    } else if (obj.hasOwnProperty('answer') && obj.hasOwnProperty('conv_ans')) {
        $('.'+id).last().append("<li></li>");
        console.log($('.'+id).last());

      
        addS(id,obj.answer);
        for(var ele in obj.conv_ans) {
            console.log("call::::");
            jsonToHtml(id + 1, obj.conv_ans[ele]);
        }
    }else if(obj.hasOwnProperty('question') ){
    	 $('.'+id).last().append("<li></li>");
         console.log($('.'+id).last());

       
         addQ(id,obj.question);
    }

}



function modifySearchData() {
	$('#data').html('');
	init();
	var appName = $('#appName').val().toString().trim();
	var id = $('#id').val().toString().trim();
	$.ajax({
				type : "POST",
				url : "/searchData",
				data : {
					"appName" : appName,
					"id" : id
				},
				success : function(res) {
					console.log(res);

					console.log("res=:" + res);
					var qa = JSON.parse(res);
					console.log("qa:" + qa.hits.hits.length);
					console.log('-------------------------------------');
					
					
					jsonToHtml("lilevel0",qa.hits.hits[0]._source);
					$('#modifybtn').css('display',"initial");


				},
				error : function(res) {
					console.log("fail");
					$('#alerttext')
							.html(
									"<h3 class='alert alert-danger'>Error  Please check ID and Application..</h3>");

				}
			});// end of ajax

}








function modifyData() {
	
	var id = document.getElementById('lilevel0');
	filejson={}
	filejson=toJson(id, filejson, -1);

	console.log("--------------------------------------------------------");
	console.log(JSON.stringify(filejson));
	console.log(filejson);
	var appName = $('#appName').val().toString().trim();
	
	
	var id = $('#id').val().toString().trim();
	if(Object.getOwnPropertyNames(filejson).length > 0){
	$.ajax({
				type : "POST",
				url : "/modifyData",
				data : {
					"appName":appName,
					"id":id,
					"jsonObj":JSON.stringify(filejson)
				},
				success : function(res) {
					//console.log(res);
					
					console.log(res);
					/*var id=res.substring(res.search('#')+2,res.length-1);
					console.log(id);*/
					Activitylog(appName,filejson.question,"MODIFY",id);
					 $('#alerttext').html("<h3 class='alert alert-success'>Success Data Modified</h3>");
					$('#data').html('');
					init();
					 $('#modifybtn').css('display',"none");
					 console.log('---------------------------------------------------------------completed');
				},
				error : function(res) {
					console.log("fail");
					$('#alerttext')
							.html(
									"<h3 class='alert alert-danger'>Error  Please check ID and Application..</h3>");

				}
			});// end of ajax
	}else{
		$('#alerttext')
		.html(
				"<h3 class='alert alert-danger'>Please Fill All The Details..</h3>");
	}
}
function addQuestion(id) {
	// alert("click");

	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	var liname = '#lilevel' + q;
	qlevel = q + 1;
	qparentlevel = q + 1;
	// alert(liname);
	var question = '<div class="form-group">'
		+ '<label class="control-label col-md-1 pt5" for="question">Question:</label>'
		+ '<div class="col-md-11">'
		+ '<textarea class="form-control" id="question" rows="1"'
		+ 'placeholder="Enter question" required="required">'
		+ '</textarea>'
		+ '<input type="hidden" id="qlevel" value="'
		+ qlevel
		+ '"/>'
		+ '<input type="hidden" id="qparentlevel" value="'
		+ qparentlevel
		+ '"/>'
		+ '</div>'
		+ '</div>'
		+ '<div class="form-group">'
		+ '<div class="col-sm-offset-2 col-sm-10">'
		+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
		+ qlevel
		+ '"'
		+ ' onclick="addQuestion(this);">Add Question</button>'
		+ ' <button type="button" class="btn btn-primary" id="addsolution" value="'
		+ qparentlevel + '"'
		+ ' onclick="addSolution(this);">Add Solution</button>' 
		
		+ ' <button type="button" class="btn btn-primary" id="addanswer" value="'
		+ qparentlevel + '"'
		+ ' onclick="addAnswer(this);">Add Answer</button>' 
		+ '</div>'
		+ '</div>';
	console.log("Conv_ans:---");
	var ulid = '#lilevel' + qlevel;
	
	
	
	if($(ulid).length>0){
		console.log("not zero");
		$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ question + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}else{
		console.log(" zero");
	$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ question + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}
	


}

function addSolution(id) {
	// alert("click");

	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	var liname = '#lilevel' + q;
	qlevel = q + 1;
	qparentlevel = q + 1;
	// alert(liname);

	var solution = '<div class="form-group">'
		+ '<label class="control-label col-md-1 pt5" for="solution">Solution:</label>'
		+ '<div class="col-md-11">'
		+ '<textarea class="form-control" id="answer" rows="1"'
		+ 'placeholder="Enter Solution" required="required">' + '</textarea>'
		+ '<input type="hidden" id="qlevel" value="' + qlevel + '"/>'
		+ '<input type="hidden" id="qparentlevel" value="' + qparentlevel
		+ '"/>' + '</div>' + '</div>'
		+ '<div class="form-group">'
		+ '<div class="col-sm-offset-2 col-sm-10">'
		+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
		+ qlevel
		+ '"'
		+ ' onclick="addQuestion(this);">Add Question</button>'
		+ '</div>'
		+ '</div>';
console.log(liname);
	var ulid = '#lilevel' + qlevel;
	
	
	
	if($(ulid).length>0){
		console.log("not zero");
		$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ solution + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}else{
		console.log(" zero");
	$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ solution + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}



}

function addAnswer(id) {
	// alert("click");

	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	console.log("id of answer----------------" + q);
	var liname = '.lilevel' + q;
	qlevel = q;
	qparentlevel = q;
	 //alert(liname);

	var answer = '<div class="form-group">'
		+ '<label class="control-label col-md-1 pt5" for="answer">Answer:</label>'
		+ '<div class="col-md-11">'
		+ '<textarea class="form-control" id="answer" rows="1"'
		+ 'placeholder="Enter Answer" required="required">' + '</textarea>'
		+ '<input type="hidden" id="qlevel" value="' + qlevel + '"/>'
		+ '<input type="hidden" id="qparentlevel" value="' + qparentlevel
		+ '"/>' + '</div>' + '</div>'
	console.log(liname);
	
	$(answer).insertBefore($(id).parent('div').parent('div'));
	$(id).prop('disabled', true);

	console.log(liname);


}
