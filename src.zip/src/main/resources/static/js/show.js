

function showData(){
	var appName=$('#appName').val().toString().trim();
	    		$.ajax({
	    			type:"GET",
	    			url: "/showData",
	    			data : {"appName" : appName
	    					
	    					},
	    			success : function(res){
	    				console.log(res);
	    				
	    				console.log("res=:"+res);
						var qa = JSON.parse(res);
						console.log("qa:"+qa.hits.hits.length);
						console.log(qa.hits.hits);
						var table="<table class='table table-striped table-bordered table-hover'><thead><tr><td>No.</td><td>ID</td><td>Type </td><td>Question</td><td>Action</td></tr></thead><tbody>";
						result = null;
						result = qa.hits.hits;
						var i=1;
						qa.hits.hits.forEach(function(entry) {
							
							console.log("source:"+entry._source.question);
							
							table+="<tr><td>"+i+"</td><td>"+entry._id+"</td><td>"+entry._type+"</td><td>"+entry._source.question+"</td><td><a href='./modify?id="+entry._id+"&appName="+entry._type+"' class='btn btn-warning'>Modify</a>"+"<a href='./delete?id="+entry._id+"&appName="+entry._type+"' class='btn btn-danger'>Delete</a>"+"</td></tr>";
							
						i=i+1;
							
						});
						table+="</tbody></table>";
						$('#databody').html(table);
						//$('#alerttext').html("<h3 class='alert alert-success'>Success Loading..</h3>");
						
					},
					error : function(res) {
						console.log("fail");
						$('#alerttext').html("<h3 class='alert alert-danger'>Error Showing data..</h3>");
						
					}
	    	});// end of ajax
	    	
}
	    	

