function toJson(id, filename, i) {

	
	console.log("i---->" + i);
	console.log(filename);

	console.log("id:" + id);
	var children = id.childNodes;
	console.log(children);
	
	children.forEach(function(item) {
			
			if (item.nodeName.toLowerCase() === 'li') {
				var json = {};
				var q = 0;
				var a = 0;
				var que = '';
				var ans = '';
				var assign=0;
				var arr=[];
				
				var ul=0;
				console.log("start of loop ");
				console.log(json);
				console.log(item);
					child1 = item.childNodes;
					console.log(child1);
					child1.forEach(function(nextitem) {
						console.log(nextitem.nodeName.toLowerCase());
								if (nextitem.nodeName.toLowerCase() === 'div') {
									child2 = nextitem.childNodes;
									child2.forEach(function(nextnextitem) {
												if (nextnextitem.nodeName.toLowerCase() === 'div') {
													child3 = nextnextitem.childNodes;
													child3.forEach(function(nextnextnextitem) {
															if (nextnextnextitem.nodeName.toLowerCase() === 'textarea') {
																	if (nextnextnextitem.id.toLowerCase() === 'question') {
																		json.question=nextnextnextitem.value.trim();
																	} else if (nextnextnextitem.id.toLowerCase() === 'answer') {
																		json.answer=nextnextnextitem.value.trim();
																	}
																}
														});
												}
											});
								}else if (nextitem.nodeName.toLowerCase() === 'ul') {
									console.log("UL found");
									filename.conv_ans = [];
									console.log("conv_arr");
									console.log(filename);
									i++;
									json.conv_ans=[];
									var tmp={};
									tmp=toJson(nextitem, tmp, -1);
									if(Object.keys(tmp).length>0)
									arr.push(tmp);
									console.log(tmp);
									console.log("temppppp");
								
									
									filename.conv_ans=json.conv_ans;
									//console.log(JSON.stringify(filename));
									console.log(JSON.stringify(json));
									//filename.push(json);
								}
								
							});

					
				console.log("loopingg");
				console.log(json);
				console.log(filename);
				if(json.hasOwnProperty("question") && json.question.length>0)
					filename.question=json.question;
				if(json.hasOwnProperty("answer") && json.answer.length>0)	
					filename.answer=json.answer;
				if(arr.length>0)
				filename.conv_ans=arr;
			
				
			}
				
			});
	console.log(JSON.stringify(filename));
	console.log("return with i-->"+i);
return filename;
}


var insertHtml="<li>"
+ '<div class="form-group">'
+ '<label class="control-labelcol-md-1 pt5" for="question">Question:</label>'
+ '<div class="col-md-11">'
+ '	<textarea class="form-control" id="question" rows="1" placeholder="Enter question" required="required"></textarea>'
+ '	<input type="hidden" id="qlevel0" value="0" />'
+ '	<input type="hidden" id="qparentlevel0" value="0" />'
+ '</div>'
+ '</div>'
+ '<div class="form-group">'
+ '<div class="col-sm-offset-2 col-sm-10">'
+ '	<button type="button" class="btn btn-primary" id="addquestion" value="0"'
+ '		onclick="addQuestion(this);">Add Question</button>'
+ '	<button type="button" class="btn btn-primary" id="addanswer" value="0"'
+ '		onclick="addAnswer(this);">Add Answer</button>'
+ '		<button type="button" class="btn btn-primary" id="addsolution" value="0"'
+ '		onclick="addSolution(this);">Add Solution</button>'
+ '</div>'
+ '</div>'
+ '</li>';







function insertData() {
	var id = document.getElementById('lilevel0');
	filejson = {}
	filejson=toJson(id, filejson, -1);

	console.log("--------------Final------------------------------------------");
	console.log(JSON.stringify(filejson));
	
	var appName = $('#appName').val().toString().trim();
	if(Object.getOwnPropertyNames(filejson).length > 0){
	if (appName.length > 0) {
		$
				.ajax({
					type : "POST",
					url : "/insertJson",
					data : {
						"appName" : appName,
						"jsonObj" : JSON.stringify(filejson)
					},

					success : function(res) {
						console.log(res);
						var id=res.substring(res.search('#')+2,res.length-1);
						console.log(id);
						Activitylog(appName,filejson.question,"INSERT",id);
						$('#alerttext')
								.html(
										"<h3 class='alert alert-success'>Data inserted successfully..</h3>");
						$("#result").removeAttr("hidden");
						$('#resulttext').addClass('btn-success').removeClass(
								'btn-danger');
						$('#resulttext').val("Success");
						$('#lilevel0').html(insertHtml);
					},
					error : function(res) {
						$('#alerttext')
								.html(
										"<h3 class='alert alert-danger'>Error inserting data..</h3>");
						console.log(res);
						$('#result').removeAttr("hidden");
						$('#resulttext').addClass('btn-danger').removeClass(
								'btn-success');
						$('#resulttext').val("Failed");

					}
				});// end of ajax
	} else {
		$('#alerttext')
				.html(
						"<h3 class='alert alert-danger'>Please Fill All The Details..</h3>");
	}
	}else{
		$('#alerttext')
		.html(
				"<h3 class='alert alert-danger'>Please Fill All The Details..</h3>");
	}
}
function addQuestion(id) {
	// alert("click");

	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	var liname = '#lilevel' + q;
	qlevel = q + 1;
	qparentlevel = q + 1;
	// alert(liname);

	var question = '<div class="form-group">'
			+ '<label class="control-label col-md-1 pt5" for="question">Question:</label>'
			+ '<div class="col-md-11">'
			+ '<textarea class="form-control" id="question" rows="1"'
			+ 'placeholder="Enter question" required="required">'
			+ '</textarea>'
			+ '<input type="hidden" id="qlevel" value="'
			+ qlevel
			+ '"/>'
			+ '<input type="hidden" id="qparentlevel" value="'
			+ qparentlevel
			+ '"/>'
			+ '</div>'
			+ '</div>'
			+ '<div class="form-group">'
			+ '<div class="col-sm-offset-2 col-sm-10">'
			+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
			+ qlevel
			+ '"'
			+ ' onclick="addQuestion(this);">Add Question</button>'
			+ ' <button type="button" class="btn btn-primary" id="addsolution" value="'
			+ qparentlevel + '"'
			+ ' onclick="addSolution(this);">Add Solution</button>' 
			
			+ ' <button type="button" class="btn btn-primary" id="addanswer" value="'
			+ qparentlevel + '"'
			+ ' onclick="addAnswer(this);">Add Answer</button>' 
			+ '</div>'
			+ '</div>';
	console.log("Conv_ans:---");
	var ulid = '#lilevel' + qlevel;
	
	
	
	if($(ulid).length>0){
		console.log("not zero");
		$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ question + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}else{
		console.log(" zero");
	$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ question + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}
	


}

function addSolution(id) {
	// alert("click");

	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	var liname = '#lilevel' + q;
	qlevel = q + 1;
	qparentlevel = q + 1;
	// alert(liname);

	var solution = '<div class="form-group">'
		+ '<label class="control-label col-md-1 pt5" for="solution">Solution:</label>'
		+ '<div class="col-md-11">'
		+ '<textarea class="form-control" id="answer" rows="1"'
		+ 'placeholder="Enter Solution" required="required">' + '</textarea>'
		+ '<input type="hidden" id="qlevel" value="' + qlevel + '"/>'
		+ '<input type="hidden" id="qparentlevel" value="' + qparentlevel
		+ '"/>' + '</div>' + '</div>'
		+ '<div class="form-group">'
		+ '<div class="col-sm-offset-2 col-sm-10">'
		+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
		+ qlevel
		+ '"'
		+ ' onclick="addQuestion(this);">Add Question</button>'
		+ '</div>'
		+ '</div>';
console.log(liname);
	var ulid = '#lilevel' + qlevel;
	
	
	if($(ulid).length>0){
		console.log("not zero");
		$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ solution + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}else{
		console.log(" zero");
	$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ solution + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}
	$(id).prop('disabled', true);

}

function addAnswer(id) {
	// alert("click");

	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	console.log("id of answer----------------" + q);
	var liname = '.lilevel' + q;
	qlevel = q;
	qparentlevel = q;
	 //alert(liname);

	var answer = '<div class="form-group">'
			+ '<label class="control-label col-md-1 pt5" for="answer">Answer:</label>'
			+ '<div class="col-md-11">'
			+ '<textarea class="form-control" id="answer" rows="1"'
			+ 'placeholder="Enter Answer" required="required">' + '</textarea>'
			+ '<input type="hidden" id="qlevel" value="' + qlevel + '"/>'
			+ '<input type="hidden" id="qparentlevel" value="' + qparentlevel
			+ '"/>' + '</div>' + '</div>'
	console.log(liname);
	
	$(answer).insertBefore($(id).parent('div').parent('div'));
	$(id).prop('disabled', true);

	console.log(liname);

}