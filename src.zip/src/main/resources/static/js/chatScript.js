var result = null;


function log(appName,q,question,thumbs,wanted,msg){
	
	
	
	$.ajax({
		type : "POST",
		url : "/log",
		data : {"appName" : appName,
			"q" : q,
			"thumbs":thumbs,
			"question":question,
			"wanted":wanted,
			"message":msg
		},
		success : function(res) {
			console.log("logging done");
		},
		error : function(res) {
			console.log("error logging");
		}
	
});
}
/////////////////////USER_WANTED_QUERIES/////////////////////////////////////////////
function Userlog(appName,q,question,thumbs,wanted,msg){
	
	
	
	$.ajax({
		type : "POST",
		url : "/Userlog",
		data : {"appName" : appName,
			"q" : q,
			"thumbs":thumbs,
			"question":question,
			"wanted":wanted,
			"message":msg
		},
		success : function(res) {
			console.log("logging done");
		},
		error : function(res) {
			console.log("error logging");
		}
	
});
}
/////////////////////////////////////////////////////////////////////////////////////


function wantedQ(id){
	console.log(id);
	let msg=$('#comment').val();
	console.log(msg);
	log($("#AppNameSelect").val(),msg,"USER WANT THIS TO BE IN THE SYSTEM","NULL",msg,"WANTED QUESTION SUBMITTED BY USER");
	Userlog($("#AppNameSelect").val(),msg,"USER WANT THIS TO BE IN THE SYSTEM","NULL",msg,"WANTED QUESTION SUBMITTED BY USER");	
	$('#wantedBtn').remove();
	
	sendMessage('This is my desired question : <br/>'+msg,2);
	sendMessage('Thanks for your feedback.',1);
	$('#comment').remove();
}


(function () {
    var Message;
    Message = function (arg) {
        this.text = arg.text, this.message_side = arg.message_side;
        this.draw = function (_this) {
            return function () {
                var $message;
                $message = $($('.message_template').clone().html());
                $message.addClass(_this.message_side).find('.text').html(_this.text);
                $('.messages').append($message);
                return setTimeout(function () {
                    return $message.addClass('appeared');
                }, 0);
            };
        }(this);
        return this;
    };
    
    $(function () {
        var getMessageText, message_side, sendMessage, appName;
        message_side = 'right';
                getMessageText = function () {
            var $message_input;
            $message_input = $('.message_input');
            return $message_input.val();
        };
        sendMessage = function (text,side) {
        	
        	//For Internet Explorer
        	 var side = side ||  0;
        	///////////////////////
        	
            var $messages, message;
            if (text.trim() === '') {
                return;
            }
            $('.message_input').val('');
            $messages = $('.messages');
            if(side=== 0){
            	message_side = message_side === 'left' ? 'right' : 'left';
            }else if(side===1){
            	message_side='left';
            }else if(side===2){
            	message_side='right';
            }
            
            message = new Message({
                text: text,
                message_side: message_side
            });
            message.draw();
            return $messages.animate({ scrollTop: $messages.prop('scrollTop')+100 }, 300);
        };
        

        
        
 /////////////////////////////////////////////////on CLICK START/////////////////////////////////////////////////////////////////////////////     
        	
        
               
        $('.send_message').click(function (e) {
        	console.log(appName);
        	if(typeof appName === "undefined" || appName=== "none"){
        		sendMessage(getMessageText())
        		return sendMessage('Please choose an application from the drop down above :-)',1);
        	}
        	var q = getMessageText();
            sendMessage(q);
            if(q.length === 0)
            	return;
            $.ajax({
            	type:"GET",
            	url: "/getvalue",
            	data : {"appName" : appName,
            			"q" : q 
            			},
            	success : function(res){
            		console.log(res);
            		var qa = JSON.parse(res);
            		console.log(qa.hits.hits.length);
            		
            		var yesno="<div class='col-lg-12 pull-right' style='font-size:small; '><a class='col-sm-5 ' style='text-decoration: none;color:white'><span>find this helpful?</span></a><button class='col-sm-1 btn btn-link btn-success' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-up' style='color:chartreuse'></span></button><button class='col-sm-1 btn btn-link btn-warning' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-down ' style='color:darkorange;'></span></button></div>";
            		if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer") ){
            				/* start added by dipu */
            				//check if answer is a query
                			
                			log(appName,q,qa.hits.hits[0].question,"NULL","NULL","QUERY ENTER");	
                			console.log(appName,q,qa.hits.hits[0].question,"NULL","NULL","QUERY ENTER");	
		
            				var ans=qa.hits.hits[0]._source.answer;
            				console.log("1.answer is this->"+qa.hits.hits[0].answer);
            				var startkey=new String(ans.substring(0,7).toLowerCase().trim());
            				startkey=startkey.toString();
            				var selectvar=new String("select");
            				selectvar=selectvar.toString();
            				console.log(startkey+"------"+selectvar);
            				

            				//this ans is to check connection working or not
            				//ans="select A.CATEGORY_DET ,ROUND(sum(A.LIMIT_VAL),2) ||' billion.' from RMWB_PERF_EXPOSURE A, CAR_ROLE_USER_MAP B where B.USER_ID = '326970' and A.UCC_ID = B.UCC_ID GROUP BY A.CATEGORY_DET ";
            				
            				if(startkey==selectvar){
            					ans=ans.replace(";","");
            					var isUserId=ans.search("&variable1");
            					console.log(isUserId);
            					ans=ans.replace(/&variable1/gi,"326970");
            					
            					var isCompany=ans.search("&variable2");
            					var isUccId=ans.search("&variable3");
            					if(isCompany!=-1 && isUccId!=-1){
            						$('#company').remove();
            						$('#sendcompany').remove();
            						$('#ans').remove();
            						$('#sendUccId').remove();
	    							$('#uccid').remove();
	    							var tmp="<div class='row'><a class='companyWrapper'>Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>";
	    							
	    							sendMessage("<div class='row'><a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' onkeyup='getList();' style='color:black;'/><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>"+tmp,1);
	    							log(appName,q,qa.hits.hits[0].question,"NULL","NULL","USER ENTERED QUERY");
	    							console.log(appName,q,qa.hits.hits[0].question,"NULL","NULL","USER ENTERED QUERY");
	                    									
            					}else if(isCompany!=-1){
            						
            						
            						$('#company').remove();
            						$('#sendcompany').remove();
            						$('#ans').remove();
            						
            						sendMessage("<a class='companyWrapper'>Please Enter Company Name: </a><input id='company' name='company' onkeyup='getList();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
            						
                        			
            						
            						
            						
            					}else if(isUccId!=-1){
            						$('#uccid').remove();

            						$('#sendUccId').remove();
            						$('#ans').remove();
            						sendMessage("<a class='col-lg-5' >Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
            						

            					
            					}else{
            					
            					console.log("Final query after all :"+ans);
            					$.ajax({
            		            	type:"GET",
            		            	url: "/executeQuery",
            		            	data : {"appName" : appName,
            		            			"q" : ans 
            		            			},
            		            	success : function(res){
            		            			sendMessage(res,1);
            		            			$('.companylist').remove();
            		            	},
            		            	error:function(res){
    	    							log(appName,ans,qa.hits.hits[0].question,"NULL","NULL","ERROR SQL QUERY");	
    	    							console.log(appName,ans,qa.hits.hits[0].question,"NULL","NULL","ERROR SQL QUERY");
            		            		sendMessage("Sorry error in sql query",1);
            		            	}
            		            });//end of ajax
            					
            					}
            				}else{
            				/* end of addd by dipu*/
            					sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+yesno);
            					log(appName,q,qa.hits.hits[0].question,"NULL","NULL","QA");	
                    			console.log(appName,q,qa.hits.hits[0].question,"NULL","NULL","QA");
            				}//this also
            			if(result.length<4){
            				$('.btn-warning').click(function(e){
            					
            					var suggest = "<h4>Suggestions :</h4>";
            					var k=0;
            					for(i=0;i<result.length;i++){
            						suggest = suggest+"<h5><button class='suggestion btn btn-responsive ' id='"+i+"' style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>"+i+".&nbsp;"+qa.hits.hits[i]._source.question+"</button></h5>";
            						k=k+1;
            					}
            					if(k>0){
            						sendMessage(suggest,1);
            						log(appName,q,qa.hits.hits[0].question,"DOWN","SUGGESTION");
            						console.log(appName,q,qa.hits.hits[0].question,"DOWN","SUGGESTION");
                        			
            					}else{
            						log(appName,q,"NO_SUGGESTED_QUESTION","DOWN","NULL");	
                        			console.log(appName,q,"NO_SUGGESTED_QUESTION","DOWN","NULL");
            						sendMessage('<form><div class="form-group"> <label for="comment">Please enter your desired question:</label> <textarea class="form-control" rows="2" id="comment"></textarea> </div><button type="button" id="wantedBtn" onclick ="wantedQ(this);" class="btn btn-default">Submit</button></form>',1);
            						
            					}
            					$('.suggestion').click(function(sgst){
            						
               					 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
               					log(appName,q,result[$(this).attr("id")]._source.question,"NULL","SUGGESTION_CLICK");
               					console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","SUGGESTION_CLICK");
                    			
            					});
            				});
            			}
            			else{
            			$('.btn-warning').click(function (e){
                        	//var feedback = prompt("Suggest your ideas to make it better :) ","Your feedback please");
            				 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='1' style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+qa.hits.hits[1]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='2'  style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+qa.hits.hits[2]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+qa.hits.hits[3]._source.question+"</button></h5>",1);
             	        	
            				 $('.suggestion').click(function(sgst){
            					 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
            					 log(appName,q,result[$(this).attr("id")]._source.question,"NULL","SUGGESTION_CLICK");
            					 console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","SUGGESTION_CLICK");
                     			
            				 });
            			
            			
            				 
                        });
            			}
            			                			
            			$('.btn-success').click(function(e){
            				log(appName,q,result[$(this).attr("id")]._source.question,"UP","NULL","SUCCESS ");
            				console.log(appName,q,result[$(this).attr("id")]._source.question,"UP","NULL","SUCCESS ");
                			
            				sendMessage("Thanks for your feedback",1);
            			});
            		
            		
            		}else if(qa.hits.hits.length>0 && qa.hits.hits[0]._source.hasOwnProperty("conv_ans")){
            			
			        	console.log('array found');
			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");
			        	console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");
   	
			        	startConversation(qa.hits.hits[0]._source.conv_ans);
			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");	
            			console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");
			        
				
            		}else{
            			log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL");
            			console.log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL");
            			
            			sendMessage("Not enough data",1);
            		}
            	},
            	error: function(res){
            		console.log(res);
            		sendMessage("Not enough data",1);
            		log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","ERROR IN SEND MSG CLICK");
            		console.log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","ERROR IN SEND MSG CLICK");
        			
            	}
            });
        });
        
        
////////////////////////////////////ON CLICK  END //////////////////////////////////////////////////////////////////////////
        
////////////////////////////////////ON KEYUP   START //////////////////////////////////////////////////////////////////////////
        
               
        $('.message_input').keyup(function (e) {
        	var words=getMessageText().split(' ');
        	//alert("words "+words);
            if(getMessageText().trim().length==0)
            	return;
        	var tmp=words[words.length-1];
        	if(tmp.trim().length==0){
        		tmp=words[words.length-2];
        	}
        	if(tmp.length==0)
        		return;
        		
        	
           // alert("tmp"+tmp);
            	console.log("temp->>>>>>>>>>>>>>"+tmp.length+">>>>>>>>>>>>"+tmp);
            	$.ajax({
                	type:"POST",
                	url: "/suggestWords",
                	data : {"appName" : appName,
                			"word" : tmp 
                			},
                	success : function(res){
                		console.log("suggest Words:"+Object.values(res));
                		//alert("result--->"+Object.values(res));
                		var sg = JSON.parse(res);
                		str=getMessageText().replace(tmp,'');
            			var cont="";
            			var i=0;
                		sg.forEach(function(entry) {
                			cont+="<li  class='list-inline-item' id='suggest_"+i+"' style='cursor: pointer; cursor: hand;'>"+str+entry.text+"</li>"
                			i+=1;
                		});

            			$('.upper_results').html(cont);
                	},error:function(res){
                		//alert("result---->"+Object.values(res));
                		console.log(Object.values(res));
                		console.log("fail");
                	}
            	});
                	
            	
            
        	
        	
        	
        	
        	
        	
        	
        	
        	
////////////////////////////////// ON KEY UP -->//ON HIT ENTER KEY //////////////////////////////////////////////////////////////////////////
                
            	  
        	
            if (e.which === 13) {
            	if(typeof appName === "undefined" || appName === "none"){
            		sendMessage(getMessageText())
            		sendMessage('Hello..!  Please choose an application from the dropdown above to let me assist you:');
            	}
            	
            	var q = getMessageText();
            	q=q.trim();
                sendMessage(q,2);
               
                
                
                
                
                
                
                if(q.length === 0)
                	return;
                
                
                
                $.ajax({
                	type:"GET",
                	url: "/getvalue",
                	data : {"appName" : appName,
                			"q" : q 
                			},
                	success : function(res){
                		console.log(res);
                		var qa = JSON.parse(res);
                		//console.log(qa.hits.hits[0].length);
                		console.log(qa.hits.hits);
                		result = qa.hits.hits;
                		console.log("Result----------------"+result);
                		//console.log(typeof(qa.hits.hits[0]._source.question));
                		var yesno="<div class='col-lg-12 pull-right' style='font-size:small; '><a class='col-sm-5 ' style='text-decoration: none;color:white'><span>find this helpful?</span></a><button class='col-sm-1 btn btn-link btn-success' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-up' style='color:chartreuse'></span></button><button class='col-sm-1 btn btn-link btn-warning' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-down ' style='color:darkorange;'></span></button></div>";
                		if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer") ){
            				/* start added by dipu */
            				//check if answer is a query
                			
                					
                			/* start added by dipu */
            				//check if answer is a query
            				var ans=qa.hits.hits[0]._source.answer;
            				console.log("2.answer is this->"+qa.hits.hits[0].answer);
            				var startkey=new String(ans.substring(0,7).toLowerCase().trim());
            				startkey=startkey.toString();
            				var selectvar=new String("select");
            				selectvar=selectvar.toString();
            				console.log(startkey+"------"+selectvar);
            				
            				
            				//this ans is to check connection working or not
            				//ans="select A.CATEGORY_DET ,ROUND(sum(A.LIMIT_VAL),2) ||' billion.' from RMWB_PERF_EXPOSURE A, CAR_ROLE_USER_MAP B where B.USER_ID = '326970' and A.UCC_ID = B.UCC_ID GROUP BY A.CATEGORY_DET ";
            				
            				
            				if(startkey==selectvar){
            					ans=ans.replace(";","");
            					var isUserId=ans.search("&variable1");
            					console.log(isUserId);
            					ans=ans.replace(/&variable1/gi,"326970");
            					var isCompany=ans.search("&variable2");
            					var isUccId=ans.search("&variable3");
            					
            					if(isCompany!=-1 && isUccId!=-1){
            						$('#company').remove();
            						$('#sendcompany').remove();
            						$('#ans').remove();
            						$('#sendUccId').remove();
	    							$('#uccid').remove();
	    							var tmp="<div class='row'><a class='companyWrapper'>Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>";
	    							
	    							sendMessage("<div class='row'><a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' onkeyup='getList();' style='color:black;'/><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>"+tmp,1);
	    							            							
	    							log(appName,q,qa.hits.hits[0].question,"NULL","NULL","SEND BUTTON CLICKED");
	    							console.log(appName,q,qa.hits.hits[0].question,"NULL","NULL","SEND BUTTON CLICKED");

            					}else if(isCompany!=-1){
            						
            						$('#company').remove();
            						$('#sendcompany').remove();
            						$('#ans').remove();
            						$('#uccid').remove();

            						$('#sendUccId').remove();
            						$('#ans').remove();
            						
            						sendMessage("<a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' onkeyup='getList();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
            						
            						
            						
            						
            					}else if(isUccId!=-1){
            						$('#uccid').remove();

            						$('#sendUccId').remove();
            						$('#ans').remove();
            						sendMessage("<a class='col-lg-5' >Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
            						

            					
            					}else{
            					console.log("Final query after all :"+ans);
            					$.ajax({
            		            	type:"GET",
            		            	url: "/executeQuery",
            		            	data : {"appName" : appName,
            		            			"q" : ans 
            		            			},
            		            	success : function(res){
            		            			sendMessage(res,1);
            		            			$('.companylist').remove();
            		            	},
            		            	error:function(res){
            		            		sendMessage("Sorry error in sql query",1);
    	    							log(appName,ans,qa.hits.hits[0].question,"NULL","NULL","ERROR IN SQL");
    	    							console.log(appName,ans,qa.hits.hits[0].question,"NULL","NULL","ERROR IN SQL");

            		            	}
            		            });//end of ajax
            					}
            				}else{
            				/* end of addd by dipu*/
                			
                			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+yesno);
                			log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","QA");
                			console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","QA");
            				}//this also 
            				
            				if(result.length<4){
                				$('.btn-warning').click(function(e){
                					let  tmp_s="";
                					var suggest = "<h4>Suggestions :</h4>";
                					var k=0;
                					for(i=1;i<result.length;i++){
                						suggest = suggest+"<h5><button class='suggestion btn btn-responsive ' id='"+i+"' style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+qa.hits.hits[i]._source.question+"</button></h5>";
                						log(appName,q,qa.hits.hits[i]._source.question,"NULL","NULL","SUGGESTION");
                						console.log(appName,q,qa.hits.hits[i]._source.question,"NULL","NULL","SUGGESTION");
                						k=k+1;
                					}
                					if(k>0){
                						sendMessage(suggest,1);
                							
                					}else{
                					log(appName,q,qa.hits.hits[0]._source.question,"DOWN","NULL","SORRY_NO_SUGGESTION");
                					console.log(appName,q,qa.hits.hits[0]._source.question,"DOWN","NULL","SORRY_NO_SUGGESTION");
                						
            						sendMessage('<form><div class="form-group"> <label for="comment">Please enter your desired question:</label> <textarea class="form-control" rows="2" id="comment"></textarea> </div><button type="button" id="wantedBtn" onclick ="wantedQ(this);" class="btn btn-default">Submit</button></form>',1);
                					}
                					$('.suggestion').click(function(sgst){
                   					 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
                   					log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION_CLICK");
                   					console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION_CLICK");
            						
                					});
                				});
                			}
                			else{
                			$('.btn-warning').click(function (e){
                            	//var feedback = prompt("Suggest your ideas to make it better :) ","Your feedback please");
                				 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='1' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+qa.hits.hits[1]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='2'  style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+qa.hits.hits[2]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+qa.hits.hits[3]._source.question+"</button></h5>",1);
                				 log(appName,q,qa.hits.hits[0]._source.question,"DOWN","NULL","SUGGESTION");
                				 console.log(appName,q,qa.hits.hits[0]._source.question,"DOWN","NULL","SUGGESTION");
                			 log(appName,q,qa.hits.hits[1]._source.question,"DOWN","NULL","SUGGESTION");
                			 console.log(appName,q,qa.hits.hits[1]._source.question,"DOWN","NULL","SUGGESTION");
                				 log(appName,q,qa.hits.hits[2]._source.question,"DOWN","NULL","SUGGESTION");	
         						console.log(appName,q,qa.hits.hits[2]._source.question,"DOWN","NULL","SUGGESTION");
                				 $('.suggestion').click(function(sgst){
                					 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
                					 log(appName,q,result[$(this).attr("id")]._source.question,"DOWN","NULL","SUGGESTION_CLICK");
                					 console.log(appName,q,result[$(this).attr("id")]._source.question,"DOWN","NULL","SUGGESTION_CLICK");
             						
                				 });
                			
                			
                				 
                            });
                			}
                			                			
                			$('.btn-success').click(function(e){
                				sendMessage("Thanks for your feedback",1);
                				log(appName,q,qa.hits.hits[0]._source.question,"UP","NULL","SUCCESS");
                				console.log(appName,q,qa.hits.hits[0]._source.question,"UP","NULL","SUCCESS");
        						
                			});
                			 
                			
                		}else if(qa.hits.hits.length>0 && qa.hits.hits[0]._source.hasOwnProperty("conv_ans")){
                			
    			        	console.log('array found');
    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");
    			        	console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");
    						
    			        	startConversation(qa.hits.hits[0]._source.conv_ans);
    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");
    			        	console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");
    						
    			        
    				
                		}else{
                			sendMessage("Not enough data<br>",1);
                			log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","NOT ENOUGH DATA");
                			console.log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","NOT ENOUGH DATA");
    						
                		}
                	},
                	error: function(res){
                		console.log(res);
                		sendMessage("Not enough data",1);
                		log(appName,q,"NO SUGGESTION","NULL","NULL","NOT ENOUGH DATA");
                		console.log(appName,q,"NO SUGGESTION","NULL","NULL","NOT ENOUGH DATA");
						
                	}
                });
                $(".results li").remove();
                result = null;
            }else if(typeof appName != "undefined"){
            	
            	
            	
            	var value = $(this).val();
            	
            
            	
				console.log(value);
				$.ajax({
					type : "GET",
					url : "/searchQuery",
					data : {"appName" : appName,
						"q" : value
					},
					success : function(res) {
						console.log("res=:"+res);
						var qa = JSON.parse(res);
						console.log("qa:"+qa.hits.hits.length);
						console.log(qa.hits.hits);
						$(".results li").remove();
						result = null;
						result = qa.hits.hits;
						var i=0;
						qa.hits.hits.forEach(function(entry) {
							$(".results").show();
							console.log("source:"+entry._source.question);
							//if(entry._source.question){
							$(".results").append(
									"<li class='show' id='"+i+"' style='cursor: pointer; cursor: hand;'><h5>" + entry._source.question
											+ "</h5></li>");
			//				log(appName,q,entry._source.question,"NULL","NULL","SUGGESTION");	
    						
							
							
							i=i+1;
							//}
						});
					},
					error : function(res) {
						console.log("fail");
						log(appName,q,"NO SUGGESTION","NULL","NULL","NOT ENOUGH DATA");	
						console.log(appName,q,"NO SUGGESTION","NULL","NULL","NOT ENOUGH DATA");	
						
						//sendMessage("Not enough data");
					}
				});
            }
        });
        
        
        
        
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /*$('form').submit(function (e){
        	alert("form submit");
        	return sendMessage(getMessageText());
        	e.preventDefault();
        });*/
        sendMessage('Hello..!  Please choose an application from the dropdown above to let me assist you:');
        
        /*setTimeout(function () {
            return sendMessage('Hi Sandy! How are you?');
        }, 1000);
        return setTimeout(function () {
            return sendMessage('I\'m fine, thank you!');
        }, 2000);*/
        $("#AppNameSelect").change(function(e){
        	if(this.value === "none")
        		appName = undefined;
        	else{
        	appName = this.value;
        	//sendMessage("You have selected <b>"+appName.toUpperCase()+"</b> application. <br/>What can I help you with ?",1);
        	sendMessage("You have selected <b>"+$('#AppNameSelect option:selected').text()+"</b> application. <br/>What can I help you with ?",1);
        	log(appName,"NULL","App_Selected_"+appName,"NULL","NULL","SELECTED APPLICATION");	
        	console.log(appName,"NULL","App_Selected_"+appName,"NULL","NULL","SELECTED APPLICATION");	
			
        	}
        });
        
        
        $(".upper_results").on('click', 'li', function(){
        	//alert($(this).text());
        	$('.message_input').val($(this).text());
        	$('.upper_results').html('');
        	log(appName,$(this).text(),"NULL","NULL","NULL","KEYWORD SUGGESTION");	
        	console.log(appName,$(this).text(),"NULL","NULL","NULL","KEYWORD SUGGESTION");	
			
        	
        });
        
        
        
        
        $(".results").on('click', 'li', function(){
        	//alert("click");
        	//(result[$(this).attr("id")]._source.question);
        	//var yesno="<div class='col-lg-12' style='margin-bottom: -1.3em;' ><p class='col-lg-5' style='margin-right: 4em;'>&nbsp;</p><span><span class='col-lg-5 ' style='color:white;font-size:small;padding-right: 0px;padding-left: 0px;margin-right: -70;' >Is this Helpful?</span><button class='col-sm-1 btn btn-link btn-success'  ><span class='glyphicon glyphicon-thumbs-up' style='color:chartreuse'></span></button><button class='col-sm-1 btn btn-link btn-warning'><span class='glyphicon glyphicon-thumbs-down ' style='color:darkorange;'></span></button></span></div>";
    		var yesno="<div class='col-lg-12 pull-right' style='font-size:small; '><a class='col-sm-5 ' style='text-decoration: none;color:white'><span>find this helpful?</span></a><button class='col-sm-1 btn btn-link btn-success' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-up' style='color:chartreuse'></span></button><button class='col-sm-1 btn btn-link btn-warning' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-down ' style='color:darkorange;'></span></button></div>";
        	
        	sendMessage(result[$(this).attr("id")]._source.question);
        	//log(appName,"CLICKED ON LINK",result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK");
        	//console.log(appName,"CLICKED ON LINK",result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK");

    		/* start added by dipu */
			//check if answer is a query
			var ans=result[$(this).attr("id")]._source;
			console.log(ans);
			 
			//this ans is to check connection working or not
			//ans="select A.CATEGORY_DET ,ROUND(sum(A.LIMIT_VAL),2) ||' billion.' from RMWB_PERF_EXPOSURE A, CAR_ROLE_USER_MAP B where B.USER_ID = '326970' and A.UCC_ID = B.UCC_ID GROUP BY A.CATEGORY_DET ";
			if(ans.hasOwnProperty('answer')  ){
				ans=result[$(this).attr("id")]._source.answer;
				console.log("3.answer is this->"+result[$(this).attr("id")]._source.answer);
				var startkey=new String(ans.substring(0,7).toLowerCase().trim());
				startkey=startkey.toString();
				var selectvar=new String("select");
				selectvar=selectvar.toString();
				console.log(startkey+"------"+selectvar);

				
			
			if(selectvar===startkey){
				ans=ans.replace(";","");
				var isUserId=ans.search("&variable1");
				console.log(isUserId);
				ans=ans.replace(/&variable1/gi,"326970");
				var isCompany=ans.search("&variable2");
				
				var isUccId=ans.search("&variable3");
	        	log(appName,"LINK CLICKED",result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND IS A  QUERY");
	        	console.log(appName,"LINK CLICKED",result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND IS A  QUERY");

				if(isCompany!=-1 && isUccId!=-1){
					$('#company').remove();
					$('#sendcompany').remove();
					$('#ans').remove();
					$('#sendUccId').remove();
					$('#uccid').remove();
					
					var tmp="<div class='row'><a class='companyWrapper'>Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>";
					
					sendMessage("<div class='row'><a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' onkeyup='getList();' style='color:black;'/><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>"+tmp,1);
										
					
				}else if(isCompany!=-1){
					
					$('#company').remove();
					$('#sendcompany').remove();
					$('#ans').remove();
					
					sendMessage("<a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' class='col-lg-5' onkeyup='getList();' style='color:black;'/><input type='submit' style=' color: black;' id='sendcompany' class='col-lg-1' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
					
					
					
					
				}else if(isUccId!=-1){
					$('#uccid').remove();

					$('#sendUccId').remove();
					$('#ans').remove();
					sendMessage("<a class='col-lg-5' >Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1 ' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
					

				
				}else{
					console.log("Final query after all :"+ans);
		        	
					$.ajax({
						type:"GET",
						url: "/executeQuery",
						data : {"appName" : appName,
								"q" : ans 
	            				},
	            		success : function(res){
	            					sendMessage(res,1);
	            					$('.companylist').remove();
	            		},
	            		error:function(res){
	            			sendMessage("Sorry error in sql query",1);
	        	        	log(appName,ans,result[$(this).attr("id")]._source.question,"NULL","NULL","ERROR IN SQL QUERY");	
	        	        	console.log(appName,ans,result[$(this).attr("id")]._source.question,"NULL","NULL","ERROR IN SQL QUERY");
	            	}
	            });// end of ajax
				
			}
			
			}else{
				
				
				sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4>"+result[$(this).attr("id")]._source.answer+yesno);
	        	log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK ");	
	        	console.log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK ");	

			}
			}else if(ans.hasOwnProperty('conv_ans')){
				//case if not sql statement 
				//case if its a direct answer or its a conversational ans//
				
			
		        	//instance of array object;
		        	console.log('array found');
		        	log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_START");
		        	console.log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_START");

		        	startConversation(ans.conv_ans);
		        	console.log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_END");	

		        	
		        }
			
			
				
				
				
				
				
				
        	
        	
        	
			//this also
			
			var ths=$(this).attr("id");
        	console.log("result ----------"+result.length);
        	$(".results").hide();
        	if(result.length<=3){
        		$('.btn-warning').click(function(){
        			console.log(ths);
        			if(ths==0 && result.lenght>=2){
        				sendMessage("<h5><button class='suggestion btn btn-responsive ' id='1' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5>",1);
    		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	

        				
        			}else if(ths==1){
        				sendMessage("<h5><button class='suggestion btn btn-responsive ' id='0' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>",1);
    		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	

        			}else if(ths==2){
        				sendMessage("<h5><button class='suggestion btn btn-responsive ' id='1' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='0' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>",1);
        				
    		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	

        			}else{
						sendMessage('<form><div class="form-group"> <label for="comment">Please enter your desired question:</label> <textarea class="form-control" rows="2" id="comment"></textarea> </div><button type="button" id="wantedBtn" onclick ="wantedQ(this);" class="btn btn-default">Submit</button></form>',1);
    		        	log(appName,getMessageText(),"NO SUGGESTION","DOWN","NULL","SUGGESTION");
    		        	console.log(appName,getMessageText(),"NO SUGGESTION","DOWN","NULL","SUGGESTION");

        			}
        			
        			$('.suggestion').on('click',function(){
            			// alert("suggestion"+$(this).attr("id")+result[$(this).attr("id")]._source.question);
            			 //sendMessage(result[$(this).attr("id")]._source.question);
    					 
            			 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
     		        	log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");
     		        	console.log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");

            		 });
        			
        		});
        		
        	}
        	else{
        	 $('.btn-warning').click(function(){
        		 //sendMessage();
             	console.log(ths);
        		 if(ths>2){
        		 
        		// sendMessage(result[$("#1").attr("id")]._source.question+"</br>"+result[$("#1").attr("id")]._source.answer+"</br></br>"+result[$("#2").attr("id")]._source.question+"</br>"+result[$("#3").attr("id")]._source.question);
        		 //sendMessage("These are some suggestions which might fulfill your need..");
        		 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='0' style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='1'  style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='2' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+result[$("#2").attr("id")]._source.question+"</button></h5>",1);
		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
		        	log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
		        	console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
		        	console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
		        	console.log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");

        		 }
        		 else{
        			 console.log(ths);
        			 console.log(result.length);
        			 if(ths==0){
        				 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='1' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='2'  style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+result[$("#2").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+result[$("#3").attr("id")]._source.question+"</button></h5>",1);
     		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");
        			 }else if(ths==1){
        				 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='0' style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='2'  style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+result[$("#2").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+result[$("#3").attr("id")]._source.question+"</button></h5>",1);
     		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");
        			 }else if(ths==2){
        				 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='0' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='1'  style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+result[$("#3").attr("id")]._source.question+"</button></h5>",1);
     		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");
    		        	
    		        	console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	console.log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");

        			 }
        			 
        		 }
        		 
        		 $('.suggestion').on('click',function(){
        			// alert("suggestion"+$(this).attr("id")+result[$(this).attr("id")]._source.question);
        			 //sendMessage(result[$(this).attr("id")]._source.question);
					 
        			 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
 		        	log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");
 		        	console.log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");

        		 });
        		 
        		 $(".results li").remove();
            	 //result=null;
        		 
        	 });
        	}
        	 $('.btn-success').click(function(e){
        		 sendMessage("Thanks for your feedback",1);
		        	log(appName,getMessageText(),result[ths]._source.question,"UP","NULL","THUMBS UP");
		        	console.log(appName,getMessageText(),result[ths]._source.question,"UP","NULL","THUMBS UP");

 			});
        	
        });
       
    });
   
    
}.call(this));



