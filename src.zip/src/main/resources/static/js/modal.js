////////////////////////////////////////////////User Management Functions Start/////////////////////////////////////////////////////


function fillUserModal(id) {
	console.log(id);
	console.log(id.id);
	console.log($('#' + id.id).attr("value"));
	if ($('#' + id.id).attr("value") === 'new') {
		$('#myuserid').val('');
		$('#myusername').val('');
		$('#mymanagerid').val('');
		$('#myissuperuser').val('');
		$('#myislocked').val('');
		$('#myroleid').val('');
		
		$('#myUserModal').modal('toggle');
	} else {
		$.ajax({
			type : "POST",
			url : "/getJsonUser",
			data : {
				"userid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				res = JSON.parse(res);
				$('#myuserid').val(res.user_id);
				$('#myusername').val(res.user_name);
				$('#mymanagerid').val(res.manager_id);
				$('#myissuperuser').val(res.is_superuser);
				$('#myislocked').val(res.is_locked);
				$('#myroleid').val(res.role_id);

				console.log(res);
				console.log($('#myuserid').value);

				$('#myUserModal').modal('toggle');

				console.log("logging done");
			},
			error : function(res) {
				console.log("error logging---------");
				console.log(res);
			}

		});
	}

}

function createUserModal(id){

	$.ajax({
		type : "POST",
		url : "/insertUser",
		data : {
			"myuser_id" : $('#myuserid').val(),
			"myuser_name" : $('#myusername').val(),
			"myrole_id" : $('#myroleid').val(),
			"mymanager_id" : $('#userid').attr('value'),
			"myis_superuser" : $('#myissuperuser').val(),
			"myis_locked" : $('#myislocked').val(),
			
		},
		success : function(res) {

			console.log(res);
			if(res==='-1'){
				console.log("error inserting");
			}else{
				
				console.log("SUCCESS INSERTING");
				
			}
			$('#createUser').attr('onclick','commit();');
			$('#createUser').html('Confirm');
			

		},
		error : function(res) {
			console.log(res);
		}

	});
	
}

////////////////////////////////////////////////User Management Functions End/////////////////////////////////////////////////////

////////////////////////////////////////////////Grant Management Functions START/////////////////////////////////////////////////////


function fillGrantModal(id) {
	console.log(id);
	console.log(id.id);
	console.log($('#' + id.id).attr("value"));

	if ($('#' + id.id).attr("value") === 'new') {
		$('#grantIdHide').hide();
		$('#granterIdHide').hide();
		//$('#mygranterid').val('');
		$('#mygrantername').val('');
		$('#myroleid').val('');
		$('#myappid').val('');
		$('#mygranteeid').val('');
		$('#mygranteename').val('');
		$('#cangrant').val('');
		$('#isvalidgrant').val('');
		
		$('#myGrantModal').modal('toggle');
	} else {
		$.ajax({
			type : "POST",
			url : "/getJsonGrant",
			data : {
				"grantid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				res = JSON.parse(res);
				$('#mygrantid').val(res.grant_id);
				$('#mygranterid').val(res.granter_id);
				$('#mygrantername').val(res.granter_name);
				$('#myroleid').val(res.role_id);
				$('#myappid').val(res.app_id);
				$('#mygranteeid').val(res.grantee_id);
				$('#mygranteename').val(res.grantee_name);
				$('#cangrant').val(res.can_grant);
				$('#isvalidgrant').val(res.is_validGrant);
				console.log(res);
				console.log($('#mygrantid').value);
	
				$('#myGrantModal').modal('toggle');
	
				console.log("logging done");
			},
			error : function(res) {
				console.log("error logging---------");
				console.log(res);
			}
		
	});
	}

}

function createGrantModal(id){
	
	//console.log("mygranter_id" + $('#mygranterid').val()+"mygranter_name" + $('#mygrantername').val()+"myrole_id" + $('#myroleid').val()+"myapp_id" + $('#myappid').val()+"mygrantee_id" + $('#mygranteeid').val()+"mygrantee_name" + $('#mygranteename').val()+"can_grant" + $('#cangrant').val()+"is_validGrant" + $('#isvalidgrant').val());
	$.ajax({
		type : "POST",
		url : "/insertGrant",
		data : {
			"mygranter_id" : $('#userid').attr('value'),
			"mygranter_name" : $('#mygrantername').val(),
			"myrole_id" : $('#myroleid').val(),
			"myapp_id" : $('#myappid').val(),
			"mygrantee_id" : $('#mygranteeid').val(),
			"mygrantee_name" : $('#mygranteename').val(),
			"can_grant" : $('#cangrant').val(),
			"is_validGrant" : $('#isvalidgrant').val(),
			
		},
		success : function(res) {

			console.log(res);
			if(res==='-1'){
				console.log("error inserting");
			}else{
				
				console.log("SUCCESS INSERTING");
				
			}
			$('#createGrant').attr('onclick','commit();');
			$('#createGrant').html('Confirm');
			

		},
		error : function(res) {
			console.log(res);
		}

	});
	
}

////////////////////////////////////////////////Grant Management Functions End/////////////////////////////////////////////////////

////////////////////////////////////////////////ROLE Management Functions START/////////////////////////////////////////////////////

function fillRoleModal(id) {
	console.log(id);
	console.log(id.id);
	console.log($('#' + id.id).attr("value"));
	
	if ($('#' + id.id).attr("value") === 'new') {
		$('#roleIdHide').hide();
		$('#myrolename').val('');
		$('#myroledetail').val('');
				
		$('#myRoleModal').modal('toggle');
	} else {
			$.ajax({
			type : "POST",
			url : "/getJsonRole",
			data : {
				"roleid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				res = JSON.parse(res);
				$('#myroleid').val(res.role_id);
				$('#myrolename').val(res.role_name);
				$('#myroledetail').val(res.details);
	
				console.log(res);
	
				$('#myRoleModal').modal('toggle');
	
				console.log("logging done");
			},
			error : function(res) {
				console.log("error logging---------");
				console.log(res);
			}
	
		});	
	}

}




function createRoleModal(id){

	$.ajax({
		type : "POST",
		url : "/insertRole",
		data : {
			"myrole_name" : $('#myrolename').val(),
			"myrole_details" : $('#myroledetail').val(),
					
		},
		success : function(res) {

			console.log(res);
			if(res==='-1'){
				console.log("error inserting");
			}else{
				
				console.log("SUCCESS INSERTING");
				
			}
			$('#createRole').attr('onclick','commit();');
			$('#createRole').html('Confirm');
			

		},
		error : function(res) {
			console.log(res);
		}

	});
	
}


////////////////////////////////////////////////ROLE Management Functions END/////////////////////////////////////////////////////

////////////////////////////////////////////////APP Management Functions START/////////////////////////////////////////////////////


function fillAppModal(id) {
	console.log(id);
	console.log(id.id);
	console.log($('#' + id.id).attr("value"));
	
	if ($('#' + id.id).attr("value") === 'new') {
		$('#appIdHide').hide();
		$('#myappname').val('');
		$('#userAppIdHide').hide();
		//$('#myuserid').val('');
		$('#myusername').val('');
		$('#appCreatedDateHide').hide();
		$('#myAppModal').modal('toggle');
	} else {
	
		$.ajax({
			type : "POST",
			url : "/getJsonApp",
			data : {
				"appid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				res = JSON.parse(res);
				$('#myappid').val(res.app_id);
				$('#myappname').val(res.app_name);
				$('#myuserid').val(res.user_id);
				$('#myusername').val(res.user_name);
				$('#mycreateddate').val(res.created_date);
	
				console.log(res);
	
				$('#myAppModal').modal('toggle');
	
				console.log("logging done");
			},
			error : function(res) {
				console.log("error logging---------");
				console.log(res);
			}
	
		});
	}

}

function createAppModal(id){

	$.ajax({
		type : "POST",
		url : "/insertApp",
		data : {
			"myapp_name" : $('#myappname').val(),
			"myuser_id" : $('#userid').attr('value'),
			"myuser_name" : $('#myusername').val(),
					
		},
		success : function(res) {

			console.log(res);
			if(res==='-1'){
				console.log("error inserting");
			}else{
				
				console.log("SUCCESS INSERTING");
				
			}
			$('#createApp').attr('onclick','commit();');
			$('#createApp').html('Confirm');
			

		},
		error : function(res) {
			console.log(res);
		}

	});
	
}

////////////////////////////////////////////////APP Management Functions END/////////////////////////////////////////////////////


////////////////////////////////////////////////COMMIT Function for SQL/////////////////////////////////////////////////////


function commit(){
	console.log("commit");

	$.ajax({
		type : "POST",
		url : "/commit",
		data : {
		},
		success : function(res) {

			console.log(res);
			if(res==='-1'){
				console.log("error commiting");
			}else{
				
				console.log("SUCCESS INSERTING");
				
			}
			$('#createUser').attr('onclick','createUserModal(this);');
			$('#createUser').html('Create');
			$('#myUserModal').modal('toggle');
			$('#createRole').attr('onclick','createRoleModal(this);');
			$('#createRole').html('Create');
			$('#myRoleModal').modal('toggle');
			$('#createGrant').attr('onclick','createGrantModal(this);');
			$('#createGrant').html('Create');
			$('#myGrantModal').modal('toggle');
			$('#createApp').attr('onclick','createAppModal(this);');
			$('#createApp').html('Create');
			$('#myAppModal').modal('toggle');

		},
		error : function(res) {
			console.log(res);
		}

	});
	
}

////////////////////////////////////////////////COMMIT Function for SQL/////////////////////////////////////////////////////


