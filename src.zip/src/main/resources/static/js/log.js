
function log(appName,q,question,thumbs,wanted,msg){
	
	
	
	$.ajax({
		type : "POST",
		url : "/log",
		data : {"appName" : appName,
			"q" : q,
			"thumbs":thumbs,
			"question":question,
			"wanted":wanted,
			"message":msg
		},
		success : function(res) {
			
			console.log("logging done");
		},
		error : function(res) {
			console.log("error logging");
		}
	
});
}

function Userlog(appName,q,question,thumbs,wanted,msg){
	
	
	
	$.ajax({
		type : "POST",
		url : "/Userlog",
		data : {"appName" : appName,
			"q" : q,
			"thumbs":thumbs,
			"question":question,
			"wanted":wanted,
			"message":msg
		},
		success : function(res) {
			console.log("logging done");
		},
		error : function(res) {
			console.log("error logging");
		}
	
});
}

function Activitylog(appName,question,action,id){
	
	
	
	$.ajax({
		type : "POST",
		url : "/Activitylog",
		data : {"appName" : appName,
			"question":question,
			"Action":action,
			"QueID":id
		},
		success : function(res) {
			console.log("Activity logging done");
		},
		error : function(res) {
			console.log("error logging");
		}
	
});
}

function UserActivitylog(id,action,sid){
	sid=sid||"NULL";
	
	
	$.ajax({
		type : "POST",
		url : "/UserActivitylog",
		data : {
			"action":action,
			"id":id,
			"sid":sid
		},
		success : function(res) {
			console.log("Activity logging done");
		},
		error : function(res) {
			console.log("error logging");
		}
	
});
}